<?php
include 'serverconfig.php';

if(isset($_GET['ecode'])){
    $ecode = trim($_GET['ecode']);

    $select_query = mysqli_query($con, "select * from employee_details where ecode='$ecode'");
    if(!$select_query){
        echo '<script>
        alert("Database Retrieval Error");                                                            
        </script>'; 
        echo mysqli_error($con);
    }else{
        while($row=mysqli_fetch_array($select_query))
          {
            $ename = $row["ename"];
            $enum = $row["enum"];
            $eaddress = $row["eaddress"];
            $eaddate = $row["eaddate"];
          }
        }
}
?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Sangeetha Groups</title>
    <meta name="description" content="Sangeetha Groups">
    <meta name="mobile-web-app-capable" content="yes"><meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">


    <link rel="stylesheet" href="vendors/chosen/chosen.min.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>



</head>

<body>
    <!-- Left Panel -->

    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.html"><span style="font-family:Garamond">Sangeetha Groups</span></a>
                <a class="navbar-brand hidden" href="index.html"><img src="images/logo2.png" alt="Logo"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="index.html"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    <h3 class="menu-title">Hollow Block</h3><!-- /.menu-title -->
                    
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" 
                        aria-expanded="false"> <i class="menu-icon ti-book"></i>Material Purchase</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-pencil-square-o"></i><a href="mpentry.php">Entry</a></li>
                            <li><i class="fa  fa-book"></i><a href="mpview.php">Report</a></li>
                        </ul>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" 
                        aria-expanded="false"> <i class="menu-icon ti-agenda"></i>Production</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-pencil-square-o"></i><a href="pdentry.php">Entry</a></li>
                            <li><i class="fa  fa-book"></i><a href="pdview.php">Report</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="stockd.php"> <i class="menu-icon ti-pie-chart"></i>Stock Details </a>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" 
                        aria-expanded="false"> <i class="menu-icon ti-stats-up"></i>Sales</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-pencil-square-o"></i><a href="#" onclick="winp()">Entry</a></li>
                            <li><i class="fa  fa-book"></i><a href="#" onclick="winp()">Report</a></li>
                        </ul>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" 
                        aria-expanded="false"> <i class="menu-icon fa fa-inr"></i>Payment</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="ti-stats-up"></i><a href="#" onclick="winp()">Sales</a></li>
                            <li><i class="ti-user"></i><a href="#" onclick="winp()">Client</a></li>
                        </ul>
                    </li>
                    
                    <h3 class="menu-title">Menu</h3>
                    <li>
                        <a href="#" onclick="winp()"> <i class="menu-icon ti-settings"></i>Settings </a>
                    </li>
                    <li>
                        <a href="logout.php"> <i class="menu-icon fa fa-sign-in"></i>Logout </a>
                    </li>
                    
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                    <div class="header-left">
                            <span>  
                               <b>Current User : Mohan </b>

                            </span> 

                      
                    </div>
                </div>

                <div class="col-sm-5">
                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="images/admin.jpg" alt="User Avatar">
                        </a>

                        <div class="user-menu dropdown-menu">
                            <a class="nav-link" href="#" onclick="winp()"><i class="fa fa-user"></i> My Profile</a>

                            <a class="nav-link" href="#" onclick="winp()"><i class="fa fa-clock-o"></i> Activity History</a>

                            <a class="nav-link" href="#" onclick="winp()"><i class="fa fa-cog"></i> Settings</a>

                            <a class="nav-link" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
                        </div>
                    </div>

                    <div class="language-select dropdown" id="language-select">
                        <a  href="config.html">
                            <i class="menu-icon ti-settings"></i>
                        </a>
                        
                    </div>

                </div>
            </div>

        </header><!-- /header -->
    <!-- Header-->
        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Edit Employee details</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="./">Dashboard</a></li>
                            
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">

                <div class="row">

                    <div class="col-xs-6 col-sm-6" style="margin: auto;">
                        <div class="card">
                           
                            <div class="card-body card-block">
                                <div class="form-group">
                                   <form method="POST" action="#" id="editeform" onsubmit="return validate()">
                                    <div class="input-group">
                                        <div class="input-group-addon"><i class="fa fa-user"></i></div>
                                        <input class="form-control" type="text" name="ename" id="ename"
                                        placeholder="Employee Name" 
                                        value="<?php echo $ename; ?>"
                                        required>
                                    </div>
                                   
                                </div>
                                <div class="form-group">
                                   
                                    <div class="input-group">
                                        <div class="input-group-addon"><i class="fa fa-info"></i></div>
                                        <input class="form-control" type="text" name="ecode" id="ecode"
                                        placeholder="Employee code"  
                                        value="<?php echo $ecode; ?>"
                                        required readonly>
                                    </div>
                                   
                                </div>
                                <div class="form-group">
                                    
                                    <div class="input-group">
                                        <div class="input-group-addon"><i class="fa fa-phone"></i></div>
                                        <input class="form-control" type="text" name="enum" id="enum"
                                        placeholder="Contact Number"
                                        value="<?php echo $enum; ?>"
                                        required>
                                    </div>
                                       
                                </div>
                                <div class="form-group">
                                    
                                    <div class="input-group">
                                        <div class="input-group-addon"><i class="fa fa-home"></i></div>
                                        <input class="form-control" type="text" name="eaddress" id="eaddress"
                                        placeholder="Address" 
                                        value="<?php echo $eaddress; ?>"
                                        required>
                                    </div>
                                       
                                </div>
                                <div class="form-group">
                                    
                                    <div class="input-group" >
                                        <div class="input-group-addon"><i class="fa fa-calendar"></i></div>
                                        <input class="form-control" type="text" name="eaddate" id="eaddate"
                                        placeholder="Current Date" 
                                        value="<?php echo $eaddate; ?>"
                                        required readonly>
                                    </div>
                                       
                                </div>
                               
                                
                                <div class="form-group">
                                    <div class="input-group">
                                        <button type="submit" name="submit" class="btn btn-success btn-block" 
                                       >Edit</button>
                                    </div>
                                </div>
                                </form>
                                <form method="POST" action="#" id="deleteeform" onsubmit="return confirm('Are you sure to delete <?php echo $ename?> from your Employee list?');">
                                <div class="form-group">
                                    <div class="input-group">
                                        <button type="submit" name="delete" class="btn btn-danger btn-block" 
                                       >Delete</button>
                                    </div>
                                </div>
                                </form>
                                <center><b><a 
                                    href="existe.php">View existing Employees</a></b></center>
                            </div>
                            
                        </div>
                    </div>

                <?php
                    if(isset($_POST["submit"])){
                        if(($_POST["ename"]!="") && ($_POST["ecode"]!="") && ($_POST["enum"]!="") &&
                        ($_POST["eaddress"]!="")){
                            
                            $ename = $_POST["ename"];
                            $ecode = $_POST["ecode"];
                            $enum = $_POST["enum"];
                            $eaddress = $_POST["eaddress"];                       

                            $update_e_query = mysqli_query($con, "update employee_details set ename='$ename',
                            enum='$enum', eaddress='$eaddress' where ecode ='$ecode' ");

                            if(!$update_e_query){
                                echo '<script>
                                alert("Update failed - database update error");                                                            
                                </script>'; 
                                echo mysqli_error($con);
                            }
                            else{
                                echo '<script>
                                alert("Update Success");
                                window.location.href = "existe.php";
                                </script>'; 
                            }
                            
                        }
                        else{
                            echo '<script>
						alert("Please fill in all the fields before proceeding further");
						window.location.href = "existe.php";
						</script>'; 
                        }
                    }
                ?>

                <?php
                    if(isset($_POST["delete"])){
                        $del_e_query = mysqli_query($con, "update employee_details set del='1' where ecode='$ecode'");
                        if(!$del_e_query){
                            echo '<script>
                                alert("Delete failed. Database deletion error");
                                window.location.href = "existe.php";
                                </script>';
                        }
                        else{
                            echo '<script>
                            alert("Deleted Successfully");
                            window.location.href = "existe.php";
                            </script>';
                        }
                    }
                        ?>
                    <script>
                                         
                    function validate() {
                            let enamelen = document.getElementById("ename").value.length;
                            let ecodelen = document.getElementById("ecode").value.length;
                            let enumlen = document.getElementById("enum").value.length;
                            let eaddresslen = document.getElementById("eaddress").value.length;
                            let eaddate = document.getElementById("eaddate").value.length;
                            
                            if(enamelen>40){
                                alert("Please limit the Employee Name within 40 characters");
                                return false;
                            }
                            if(enamelen==0){
                                alert("Please fill in the Employee name");
                                return false;
                            }
                            if(ecodelen>12){
                                alert("Please don't use More than 6 words or 40 characters in the Employee Name");
                                return false;
                            }
                            if(ecodelen==0){
                                alert("Employee ID is not generated. Please try again");
                                window.location.href = "existe.php";
                                return false;
                            }
                            if(enumlen>30){
                                alert("Please limit the Contact Number within 30 characters");
                                return false;
                            }
                            if(enumlen==0){
                                alert("Please fill in the contact number");
                                return false;
                            }
                            if(eaddresslen>250){
                                alert("Please limit the Employee Address within 250 characters");
                                return false;
                            }
                            if(eaddresslen==0){
                                alert("Please fill in the Employee address");
                                return false;
                            }
                            

                            return true;

                          }
                    </script>
                    <!-- <div class="col-xs-6 col-sm-6">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Standard Select</strong>
                            </div>
                            <div class="card-body">

                                <select data-placeholder="Choose a Country..." class="standardSelect" tabindex="1">
                                    <option value=""></option>
                                    <option value="United States">United States</option>
                                    <option value="United Kingdom">United Kingdom</option>
                                    <option value="Afghanistan">Afghanistan</option>
                                    <option value="Aland Islands">Aland Islands</option>
                                    <option value="Albania">Albania</option>
                                    <option value="Algeria">Algeria</option>
                                    <option value="American Samoa">American Samoa</option>
                                    <option value="Andorra">Andorra</option>
                                    <option value="Angola">Angola</option>
                                    <option value="Anguilla">Anguilla</option>
                                    <option value="Antarctica">Antarctica</option>
                                </select>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Multi Select</strong>
                            </div>
                            <div class="card-body">

                                <select data-placeholder="Choose a country..." multiple class="standardSelect">
                                    <option value=""></option>
                                    <option value="United States">United States</option>
                                    <option value="United Kingdom">United Kingdom</option>
                                    <option value="Afghanistan">Afghanistan</option>
                                    <option value="Aland Islands">Aland Islands</option>
                                    <option value="Albania">Albania</option>
                                    <option value="Algeria">Algeria</option>
                                    <option value="American Samoa">American Samoa</option>
                                    <option value="Andorra">Andorra</option>
                                    <option value="Angola">Angola</option>
                                    <option value="Anguilla">Anguilla</option>
                                    <option value="Antarctica">Antarctica</option>
                                </select>

                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Multi Select with Groups</strong>
                            </div>
                            <div class="card-body">

                                <select data-placeholder="Your Favorite Football Team" multiple class="standardSelect" tabindex="5">
                                    <option value=""></option>
                                    <optgroup label="NFC EAST">
                                        <option>Dallas Cowboys</option>
                                        <option>New York Giants</option>
                                        <option>Philadelphia Eagles</option>
                                        <option>Washington Redskins</option>
                                    </optgroup>
                                    <optgroup label="NFC NORTH">
                                        <option>Chicago Bears</option>
                                        <option>Detroit Lions</option>
                                        <option>Green Bay Packers</option>
                                        <option>Minnesota Vikings</option>
                                    </optgroup>
                                    <optgroup label="NFC SOUTH">
                                        <option>Atlanta Falcons</option>
                                        <option>Carolina Panthers</option>
                                        <option>New Orleans Saints</option>
                                        <option>Tampa Bay Buccaneers</option>
                                    </optgroup>
                                    <optgroup label="NFC WEST">
                                        <option>Arizona Cardinals</option>
                                        <option>St. Louis Rams</option>
                                        <option>San Francisco 49ers</option>
                                        <option>Seattle Seahawks</option>
                                    </optgroup>
                                    <optgroup label="AFC EAST">
                                        <option>Buffalo Bills</option>
                                        <option>Miami Dolphins</option>
                                        <option>New England Patriots</option>
                                        <option>New York Jets</option>
                                    </optgroup>
                                    <optgroup label="AFC NORTH">
                                        <option>Baltimore Ravens</option>
                                        <option>Cincinnati Bengals</option>
                                        <option>Cleveland Browns</option>
                                        <option>Pittsburgh Steelers</option>
                                    </optgroup>
                                    <optgroup label="AFC SOUTH">
                                        <option>Houston Texans</option>
                                        <option>Indianapolis Colts</option>
                                        <option>Jacksonville Jaguars</option>
                                        <option>Tennessee Titans</option>
                                    </optgroup>
                                    <optgroup label="AFC WEST">
                                        <option>Denver Broncos</option>
                                        <option>Kansas City Chiefs</option>
                                        <option>Oakland Raiders</option>
                                        <option>San Diego Chargers</option>
                                    </optgroup>
                                </select>
                            </div>
                        </div>
                    </div> -->
                </div>
            </div><!-- .animated -->
        </div><!-- .content -->

        

    </div><!-- /#right-panel -->

    <!-- Right Panel -->

    <script>
        function winp(){
            alert("Work in Progress. Please check it out later");
        }
    </script>

<script src="vendors/jquery/dist/jquery.min.js"></script>
<script src="vendors/popper.js/dist/umd/popper.min.js"></script>
<script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="assets/js/main.js"></script>
<script src="vendors/chosen/chosen.jquery.min.js"></script>

<script>
    jQuery(document).ready(function() {
        jQuery(".standardSelect").chosen({
            disable_search_threshold: 10,
            no_results_text: "Oops, nothing found!",
            width: "100%"
        });
    });
</script>

</body>

</html>
