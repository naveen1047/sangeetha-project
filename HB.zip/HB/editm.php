<?php
include 'serverconfig.php';

if(isset($_GET['mcode'])){
    $mcode = trim($_GET['mcode']);

    $select_query = mysqli_query($con, "select * from material_details where mcode='$mcode'");
    if(!$select_query){
        echo '<script>
        alert("Database Retrieval Error");                                                            
        </script>'; 
        echo mysqli_error($con);
    }else{
    while($row=mysqli_fetch_array($select_query))
      {
        $mname = $row["mname"];
        $munit = $row["munit"];
        $mpriceperunit = $row["mpriceperunit"];
      }
    }
}
?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Sangeetha Groups</title>
    <meta name="description" content="Sangeetha Groups">
    <meta name="mobile-web-app-capable" content="yes"><meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">


    <link rel="stylesheet" href="vendors/chosen/chosen.min.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>



</head>

<body>
    <!-- Left Panel -->

    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.html"><span style="font-family:Garamond">Sangeetha Groups</span></a>
                <a class="navbar-brand hidden" href="index.html"><img src="images/logo2.png" alt="Logo"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="index.html"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    <h3 class="menu-title">Hollow Block</h3><!-- /.menu-title -->
                    
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" 
                        aria-expanded="false"> <i class="menu-icon ti-book"></i>Material Purchase</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-pencil-square-o"></i><a href="mpentry.php">Entry</a></li>
                            <li><i class="fa  fa-book"></i><a href="mpview.php">Report</a></li>
                        </ul>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" 
                        aria-expanded="false"> <i class="menu-icon ti-agenda"></i>Production</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-pencil-square-o"></i><a href="pdentry.php">Entry</a></li>
                            <li><i class="fa  fa-book"></i><a href="pdview.php">Report</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="stockd.php"> <i class="menu-icon ti-pie-chart"></i>Stock Details </a>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" 
                        aria-expanded="false"> <i class="menu-icon ti-stats-up"></i>Sales</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-pencil-square-o"></i><a href="#" onclick="winp()">Entry</a></li>
                            <li><i class="fa  fa-book"></i><a href="#" onclick="winp()">Report</a></li>
                        </ul>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" 
                        aria-expanded="false"> <i class="menu-icon fa fa-inr"></i>Payment</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="ti-stats-up"></i><a href="#" onclick="winp()">Sales</a></li>
                            <li><i class="ti-user"></i><a href="#" onclick="winp()">Client</a></li>
                        </ul>
                    </li>
                    
                    <h3 class="menu-title">Menu</h3>
                    <li>
                        <a href="#" onclick="winp()"> <i class="menu-icon ti-settings"></i>Settings </a>
                    </li>
                    <li>
                        <a href="logout.php"> <i class="menu-icon fa fa-sign-in"></i>Logout </a>
                    </li>
                    
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                    <div class="header-left">
                            <span>  
                               <b>Current User : Mohan </b>

                            </span> 

                      
                    </div>
                </div>

                <div class="col-sm-5">
                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="images/admin.jpg" alt="User Avatar">
                        </a>

                        <div class="user-menu dropdown-menu">
                            <a class="nav-link" href="#" onclick="winp()"><i class="fa fa-user"></i> My Profile</a>

                            <a class="nav-link" href="#" onclick="winp()"><i class="fa fa-clock-o"></i> Activity History</a>

                            <a class="nav-link" href="#" onclick="winp()"><i class="fa fa-cog"></i> Settings</a>

                            <a class="nav-link" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
                        </div>
                    </div>

                    <div class="language-select dropdown" id="language-select">
                        <a  href="config.html">
                            <i class="menu-icon ti-settings"></i>
                        </a>
                        
                    </div>

                </div>
            </div>

        </header><!-- /header -->
    <!-- Header-->

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                    <h1>Edit Materials  &nbsp<a href="existm.php"><i class="fa fa-book"></i></a></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="index.html">Dashboard</a></li>
                            
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">

                <div class="row">

                    <div class="col-xs-6 col-sm-6" style="margin: auto;">
                        <div class="card">

                            <form method="POST" action="#" onsubmit="return validate()">
                           
                            <div class="card-body card-block">
                                <div class="form-group">
                                   
                                    <div class="input-group">
                                        <div class="input-group-addon" ><i class="fa fa-tag"></i></div>
                                        <input class="form-control" type="text" name="mname" id="mname"
                                        placeholder="Material Name" 
                                        value="<?php echo $mname; ?>"
                                        required>
                                    </div>
                                   
                                </div>
                                <div class="form-group">
                                   
                                    <div class="input-group">
                                        <div class="input-group-addon" ><i class="fa fa-info"></i></div>
                                        <input class="form-control" type="text" name="mcode" id="mcode"
                                        placeholder="Material Code"
                                        value="<?php echo $mcode; ?>"
                                        required readonly>
                                    </div>
                                   
                                </div>
                                <div class="form-group">
                                    
                                    <div class="input-group">
                                        <div class="input-group-addon"><i class="fa fa-angle-double-right"></i></div>
                                        <input class="form-control" type="text" name="munit" id="munit"
                                        placeholder="Unit ( Kg, Load etc )" 
                                        value="<?php echo $munit; ?>"
                                        required>
                                    </div>
                                       
                                </div>
                                <div class="form-group">
                                    
                                    <div class="input-group">
                                        <div class="input-group-addon"><i class="fa fa-inr"></i></div>
                                        <input class="form-control" type="number" name="mpriceperunit"
                                        id="mpriceperunit" placeholder="Price per unit" 
                                        value="<?php echo $mpriceperunit; ?>"
                                        required>
                                    </div>
                                       
                                </div>
                               
                                <div class="form-group">
                                    <div class="input-group">
                                        <button type="submit" name="submit" class="btn btn-success btn-block" 
                                       >Upload</button>
                                    </div>
                                </div>
                                </form>
                                <form method="POST" action="#" id="deletemform" onsubmit="return confirm('Are you sure to delete <?php echo $mname?> from your Material list?');">
                                <div class="form-group">
                                    <div class="input-group">
                                        <button type="submit" name="delete" class="btn btn-danger btn-block" 
                                       >Delete</button>
                                    </div>
                                </div>
                                </form>
                                <center><b><a 
                                    href="existm.php">View existing Materials</a></b></center>
                            </div>
                            
                            
                        </div>
                    </div>

                    <?php

                    if(isset($_POST["submit"])){
                        if(($_POST["mname"] != "") && ($_POST["mcode"] != "") && ($_POST["munit"] != "") && 
                        ($_POST["mpriceperunit"] != "")){
                            
                            $mname =$_POST["mname"];
                            $mcode =$_POST["mcode"];
                            $munit =$_POST["munit"];
                            $mpriceperunit =$_POST["mpriceperunit"];
                                                       
                            $check_duplicate = mysqli_query($con,"select * from material_details where mname='$mname' && del=''");
                            $check_duplicate_count1 = mysqli_num_rows($check_duplicate);
                            if($check_duplicate_count1>0){
                                $check_duplicate2 = mysqli_query($con,"select * from material_details where mname='$mname' && mcode='$mcode' && del=''");
                                $check_duplicate_count2 = mysqli_num_rows($check_duplicate2);
                                if($check_duplicate_count1 == $check_duplicate_count2){
                                    $update_m_query = mysqli_query($con, "update material_details set mname='$mname', munit='$munit', mpriceperunit='$mpriceperunit' where mcode='$mcode'");
                                    if(!$update_m_query){
                                        echo '<script>
                                        alert("Upload failed - database upload error");                                                            
                                        </script>'; 
                                        echo mysqli_error($con);
                                    }
                                    else{
                                        echo '<script>
                                        alert("Update Success");    
                                        window.location.href = "existm.php";                                                        
                                        </script>';
                                    }

                                }else{
                                echo '<script>
                                alert("Material '.$mname.' already exists. Please Use different material");  
                                window.location.href="existm.php";                                                          
                                </script>'; 
                                }
                                
                            }else{
                                
                                $update_m_query = mysqli_query($con, "update material_details set mname='$mname', munit='$munit', mpriceperunit='$mpriceperunit' where mcode='$mcode'");
                                if(!$update_m_query){
                                    echo '<script>
                                    alert("Upload failed - database upload error");                                                            
                                    </script>'; 
                                    echo mysqli_error($con);
                                }
                                else{
                                    echo '<script>
                                    alert("Update Success");    
                                    window.location.href = "existm.php";                                                        
                                    </script>';
                                }
                            }
                         

                        }
                        else{
                            echo '
                            <script>
                            alert("Please fill in all the fields before proceeding further");
                            window.location.href="existm.php";
                            </script>
                            ';
                        }

                    }

                    ?>

<?php
                    if(isset($_POST["delete"])){
                        $del_m_query = mysqli_query($con, "update material_details set del='1' where mcode='$mcode'");
                        if(!$del_m_query){
                            echo '<script>
                                alert("Delete failed. Database deletion error");
                                window.location.href = "exists.php";
                                </script>';
                        }
                        else{
                            echo '<script>
                            alert("Deleted Successfully");
                            window.location.href = "existm.php";
                            </script>';
                        }
                    }
                        ?>


                    <script>
                        
                        
                            function validate() {
                                let mname = document.getElementById("mname").value.length;
                                let mcode = document.getElementById("mcode").value.length;
                                let munit = document.getElementById("munit").value.length;
                                let mpriceperunit = document.getElementById("mpriceperunit").value.length;
    
                                if(mname>30){
                                    alert("Please limit the Material Name within 30 characters");
                                    return false;
                                }
                                if(mname==0){
                                    alert("Please fill in the material name");
                                    return false;
                                }
                                if(mcode>10){
                                    alert("Please don't use More than 7 words or 30 characters in the Material Name");
                                    return false;
                                }
                                if(munit>15){
                                    alert("Please limit the Material Unit within 15 characters");
                                    return false;
                                }
                                if(munit==0){
                                    alert("Please fill in the unit for the material");
                                    return false;
                                }
                                if(mpriceperunit>10){
                                    alert("Please limit the Price per unit within 10 characters");
                                    return false;
                                }
                                if(mpriceperunit==0){
                                    alert("Please fill in the Price per unit for the material");
                                    return false;
                                }
                                if(mcode==0){
                                alert("Material code is not generated. Please try again");
                                window.location.href = "existm.php";
                                return false;
                                }
                            
                            
                            
                                return true;
    
                                    }
                                     </script>
                    <!-- <div class="col-xs-6 col-sm-6">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Standard Select</strong>
                            </div>
                            <div class="card-body">

                                <select data-placeholder="Choose a Country..." class="standardSelect" tabindex="1">
                                    <option value=""></option>
                                    <option value="United States">United States</option>
                                    <option value="United Kingdom">United Kingdom</option>
                                    <option value="Afghanistan">Afghanistan</option>
                                    <option value="Aland Islands">Aland Islands</option>
                                    <option value="Albania">Albania</option>
                                    <option value="Algeria">Algeria</option>
                                    <option value="American Samoa">American Samoa</option>
                                    <option value="Andorra">Andorra</option>
                                    <option value="Angola">Angola</option>
                                    <option value="Anguilla">Anguilla</option>
                                    <option value="Antarctica">Antarctica</option>
                                </select>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Multi Select</strong>
                            </div>
                            <div class="card-body">

                                <select data-placeholder="Choose a country..." multiple class="standardSelect">
                                    <option value=""></option>
                                    <option value="United States">United States</option>
                                    <option value="United Kingdom">United Kingdom</option>
                                    <option value="Afghanistan">Afghanistan</option>
                                    <option value="Aland Islands">Aland Islands</option>
                                    <option value="Albania">Albania</option>
                                    <option value="Algeria">Algeria</option>
                                    <option value="American Samoa">American Samoa</option>
                                    <option value="Andorra">Andorra</option>
                                    <option value="Angola">Angola</option>
                                    <option value="Anguilla">Anguilla</option>
                                    <option value="Antarctica">Antarctica</option>
                                </select>

                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Multi Select with Groups</strong>
                            </div>
                            <div class="card-body">

                                <select data-placeholder="Your Favorite Football Team" multiple class="standardSelect" tabindex="5">
                                    <option value=""></option>
                                    <optgroup label="NFC EAST">
                                        <option>Dallas Cowboys</option>
                                        <option>New York Giants</option>
                                        <option>Philadelphia Eagles</option>
                                        <option>Washington Redskins</option>
                                    </optgroup>
                                    <optgroup label="NFC NORTH">
                                        <option>Chicago Bears</option>
                                        <option>Detroit Lions</option>
                                        <option>Green Bay Packers</option>
                                        <option>Minnesota Vikings</option>
                                    </optgroup>
                                    <optgroup label="NFC SOUTH">
                                        <option>Atlanta Falcons</option>
                                        <option>Carolina Panthers</option>
                                        <option>New Orleans Saints</option>
                                        <option>Tampa Bay Buccaneers</option>
                                    </optgroup>
                                    <optgroup label="NFC WEST">
                                        <option>Arizona Cardinals</option>
                                        <option>St. Louis Rams</option>
                                        <option>San Francisco 49ers</option>
                                        <option>Seattle Seahawks</option>
                                    </optgroup>
                                    <optgroup label="AFC EAST">
                                        <option>Buffalo Bills</option>
                                        <option>Miami Dolphins</option>
                                        <option>New England Patriots</option>
                                        <option>New York Jets</option>
                                    </optgroup>
                                    <optgroup label="AFC NORTH">
                                        <option>Baltimore Ravens</option>
                                        <option>Cincinnati Bengals</option>
                                        <option>Cleveland Browns</option>
                                        <option>Pittsburgh Steelers</option>
                                    </optgroup>
                                    <optgroup label="AFC SOUTH">
                                        <option>Houston Texans</option>
                                        <option>Indianapolis Colts</option>
                                        <option>Jacksonville Jaguars</option>
                                        <option>Tennessee Titans</option>
                                    </optgroup>
                                    <optgroup label="AFC WEST">
                                        <option>Denver Broncos</option>
                                        <option>Kansas City Chiefs</option>
                                        <option>Oakland Raiders</option>
                                        <option>San Diego Chargers</option>
                                    </optgroup>
                                </select>
                            </div>
                        </div>
                    </div> -->
                </div>
            </div><!-- .animated -->
        </div><!-- .content -->

        

    </div><!-- /#right-panel -->

    <!-- Right Panel -->

    <script>
        function winp(){
            alert("Work in Progress. Please check it out later");
        }
    </script>
<script src="vendors/jquery/dist/jquery.min.js"></script>
<script src="vendors/popper.js/dist/umd/popper.min.js"></script>
<script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="assets/js/main.js"></script>
<script src="vendors/chosen/chosen.jquery.min.js"></script>

<script>
    jQuery(document).ready(function() {
        jQuery(".standardSelect").chosen({
            disable_search_threshold: 10,
            no_results_text: "Oops, nothing found!",
            width: "100%"
        });
    });
</script>

</body>

</html>
