<?php
include 'serverconfig.php';
if(isset($_GET['mpcode'])){
    $mpcode = trim($_GET['mpcode']);

    $select_query = mysqli_query($con, "select * from material_purchase where mpcode='$mpcode'");
    if(!$select_query){
        echo '<script>
        alert("Database Retrieval Error");                                                            
        </script>'; 
        echo mysqli_error($con);
    }else{
    while($rowmp=mysqli_fetch_array($select_query))
      {
        $date = $rowmp["date"];
        $scode = $rowmp["scode"];
        $billno = $rowmp["billno"];
        $mcode = $rowmp["mcode"];
        $quantity = $rowmp["quantity"];
        $unitprice  = $rowmp["unitprice"];
        $price = $rowmp["price"];
        $remarks = $rowmp["remarks"];
      }
    }
}
?>

<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Sangeetha Groups</title>
    <meta name="description" content="Sangeetha Groups">
    <meta name="mobile-web-app-capable" content="yes"><meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">


    <link rel="stylesheet" href="vendors/chosen/chosen.min.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>



</head>

<body>
    <!-- Left Panel -->
    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.html"><span style="font-family:Garamond">Sangeetha Groups</span></a>
                <a class="navbar-brand hidden" href="index.html"><img src="images/logo2.png" alt="Logo"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="index.html"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    <h3 class="menu-title">Hollow Block</h3><!-- /.menu-title -->
                    
                    <li class="menu-item-has-children dropdown active">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" 
                        aria-expanded="false"> <i class="menu-icon ti-book"></i>Material Purchase</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-pencil-square-o"></i><a href="mpentry.php">Entry</a></li>
                            <li><i class="fa  fa-book"></i><a href="mpview.php">Report</a></li>
                        </ul>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" 
                        aria-expanded="false"> <i class="menu-icon ti-agenda"></i>Production</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-pencil-square-o"></i><a href="pdentry.php">Entry</a></li>
                            <li><i class="fa  fa-book"></i><a href="pdview.php">Report</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="stockd.php"> <i class="menu-icon ti-pie-chart"></i>Stock Details </a>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" 
                        aria-expanded="false"> <i class="menu-icon ti-stats-up"></i>Sales</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-pencil-square-o"></i><a href="#" onclick="winp()">Entry</a></li>
                            <li><i class="fa  fa-book"></i><a href="#" onclick="winp()">Report</a></li>
                        </ul>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" 
                        aria-expanded="false"> <i class="menu-icon fa fa-inr"></i>Payment</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="ti-stats-up"></i><a href="#" onclick="winp()">Sales</a></li>
                            <li><i class="ti-user"></i><a href="#" onclick="winp()">Client</a></li>
                        </ul>
                    </li>
                    
                    <h3 class="menu-title">Menu</h3>
                    <li>
                        <a href="#" onclick="winp()"> <i class="menu-icon ti-settings"></i>Settings </a>
                    </li>
                    <li>
                        <a href="logout.php"> <i class="menu-icon fa fa-sign-in"></i>Logout </a>
                    </li>
                    
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                    <div class="header-left">
                            <span>  
                               <b>Current User : Mohan </b>

                            </span> 

                      
                    </div>
                </div>

                <div class="col-sm-5">
                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="images/admin.jpg" alt="User Avatar">
                        </a>

                        <div class="user-menu dropdown-menu">
                            <a class="nav-link" href="#" onclick="winp()"><i class="fa fa-user"></i> My Profile</a>

                            <a class="nav-link" href="#" onclick="winp()"><i class="fa fa-clock-o"></i> Activity History</a>

                            <a class="nav-link" href="#" onclick="winp()"><i class="fa fa-cog"></i> Settings</a>

                            <a class="nav-link" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
                        </div>
                    </div>

                    <div class="language-select dropdown" id="language-select">
                        <a  href="config.html">
                            <i class="menu-icon ti-settings"></i>
                        </a>
                        
                    </div>

                </div>
            </div>

        </header><!-- /header -->
    <!-- Header-->
        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Edit Purchase &nbsp<a href="mpview.php"><i class="fa fa-book"></i></a></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="index.html">Dashboard</a></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">

                <div class="row">

                    <div class="col-xs-6 col-sm-6" style="margin: auto;">
                        <div class="card">
                        <form method="POST" action="#" id="editmpform" onsubmit="return validate()">
                           
                            <div class="card-body card-block">
                            <div class="form-group">
                                
                                <div class="input-group">
                                   
                                    <select data-placeholder="Supplier Name" class="standardSelect" tabindex="1"
                                    name="sname" id="sname" style="width:100%" required>
                                   

                                    <?php
                                    $fetch_suppliers = mysqli_query($con, "select scode, sname from supplier_details where del=''");
                                    if(!$fetch_suppliers){
                                        echo '
                                        <script>
                                            alert("database connectivity error);
                                        </script>
                                        ';
                                        echo mysqli_error($con);
                                    }
                                    while($row1=mysqli_fetch_array($fetch_suppliers)){
                                        ?>
                                        <option <?php echo ($row1['scode'] == $scode)?"selected":""; ?> 
                                        value="<?php echo $row1['scode']; ?>"><?php echo $row1['sname']; ?></option>
                                        <?php
                                    }
                                    ?>
                                    </select>
                                </div>
                               
                            </div>
                                <div class="form-group">
                                   
                                    <div class="input-group" data-toggle="tooltip" data-placement="top" title="Date">
                                        <div class="input-group-addon"><i class="fa fa-calendar"></i></div>
                                        <input class="form-control" type="date" name="date" id="date" 
                                        value="<?php echo $date; ?>"
                                        required>
                                    </div>
                                   
                                </div>
                                <div class="form-group">
                                    
                                    <div class="input-group" data-toggle="tooltip" data-placement="top" title="Bill Number">
                                        <div class="input-group-addon"><i class="fa fa-book"></i></div>
                                        <input class="form-control" type="text" name="billno" id="billno"
                                        placeholder="Bill Number"  value="<?php echo $billno; ?>" required>
                                    </div>
                                       
                                </div>
                               
                                <div class="form-group">
                                
                                    <div class="input-group">
                                       
                                        <select data-placeholder="Material" class="standardSelect" 
                                         tabindex="1" style="width:100%"  name="mname" id="mname" onchange="pricecalc()" required>
                                     

                                            <?php
                                        $fetch_materials = mysqli_query($con, "select * from material_details where del=''");
                                        if(!$fetch_materials){
                                            echo '
                                            <script>
                                                alert("database connectivity error);
                                            </script>
                                            ';
                                            echo mysqli_error($con);
                                        }
                                        while($row2=mysqli_fetch_array($fetch_materials)){
                                            ?>
                                            <option <?php echo ($row2['mcode'] == $mcode)?"selected":""; ?> 
                                             value="<?php echo $row2['mcode']."*".$row2['mpriceperunit']; ?>"><?php echo $row2['mname']."  - Rs. ".$row2["mpriceperunit"]." per ".$row2["munit"]; ?></option>
                                            <?php
                                        }
                                        ?>
                                            
                                        </select>
                                    </div>
                                    
                                </div>
                                <div class="form-group">
                               
                                    <div class="input-group" data-toggle="tooltip" data-placement="top" title="Unit Price">
                                    
                                        <div class="input-group-addon" style="padding-left:16px;padding-right:16px;"><i class="fa fa-inr"></i></div>
                                        <input class="form-control" type="number" 
                                        value="<?php echo $unitprice ; ?>"
                                        placeholder="Unit Price" name="unitprice" id="unitprice" oninput="pricecalc2()" readOnly required>
                                        <input class="form-control"  placeholder="Unit Price"
                                        style="border-right:0px;" disabled>
                                        <div class="input-group-addon" id="rd" onclick="rd()"><i class="fa fa-pencil"></i></div>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <div class="input-group" data-toggle="tooltip" data-placement="top" title="Quantity">
                                        <div class="input-group-addon"><i class="fa fa-tags"></i></div>
                                        <input class="form-control" type="number" 
                                        value="<?php echo $quantity; ?>"
                                        placeholder="Quantity" name="quantity" id="quantity" oninput="pricecalc2()" required>
                                        <input class="form-control" placeholder="Quantity"
                                        style="border-left:0px;" disabled>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <div class="input-group" data-toggle="tooltip" data-placement="top" title="Total Price">
                                    
                                        <div class="input-group-addon" style="padding-left:16px;padding-right:16px;"><i class="fa fa-inr"></i></div>
                                        <input class="form-control" placeholder="Price" name="price" 
                                        value="<?php echo $price; ?>"
                                         id="price" required>
                                         <input class="form-control" placeholder="Total Price"
                                        style="border-left:0px;" disabled>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="input-group" data-toggle="tooltip" data-placement="top" title="Remarks">
                                        <textarea 
                                        rows="1" placeholder="Remarks" class="form-control" id="remarks" name="remarks" maxlength="100"><?php echo $remarks; ?></textarea>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="input-group">
                                        <button type="submit" name="submit" class="btn btn-success btn-block" 
                                       >Update</button>
                                       
                                    </div>
                                </div>
                                </form>
                                
                                <form method="POST" action="#" onsubmit="return confirm('Are you sure to delete this record from your Material purchase report?');">
                                <div class="form-group" style="margin-top:-10px">
                                    <div class="input-group">
                                        <button type="submit" name="delete" class="btn btn-danger btn-block" 
                                       >Delete</button>
                                    </div>
                                </div>
                                    </form>

                                    <center><b><a 
                                    href="mpview.php">View Material Purchase Report</a></b></center>

                            </div>
                       
                        </div>
                    </div>
<?php
    if(isset($_POST["submit"])){
        if(($_POST["date"] != "") && ($_POST["billno"] != "") && ($_POST["sname"] != "") && 
        ($_POST["mname"] != "") && ($_POST["quantity"] != "") && ($_POST["price"] != "") && ($_POST["unitprice"] != "")){

           
                        $date = $_POST["date"];
                        $billno = $_POST["billno"];
                        $scode = $_POST["sname"];
                        $mcode = $_POST["mname"];
                        $mcode2 = explode("*",$mcode);
                        $quantity = $_POST["quantity"];
                        $price = $_POST["price"];
                        $unitprice = $_POST["unitprice"];
                        $remarks = $_POST["remarks"];

                        $update_mp_query = mysqli_query($con, "
                        update material_purchase set 
                        scode='$scode',
                        date='$date',
                        billno='$billno',
                        mcode='$mcode2[0]',
                        quantity = '$quantity',
                        unitprice='$unitprice',
                        price = '$price',
                        remarks = '$remarks' where mpcode='$mpcode'");
                                if(!$update_mp_query){
                                    echo '<script>
                                    alert("Upload failed - database upload error");                                                            
                                    </script>'; 
                                    echo mysqli_error($con);
                                }
                                else{
                                    echo '<script>
                                    alert("Update Success");    
                                    window.location.href = "mpview.php";                                                        
                                    </script>';
                                }

                    
        }
        else{
            echo '
            <script>
            alert("Please fill in all the fields before proceeding further");
            window.location.href="mpview.php";
            </script>
            ';
        }
    }
?>
                
                <?php
                    if(isset($_POST["delete"])){
                        $del_mp_query = mysqli_query($con, "update material_purchase set del='1' where mpcode='$mpcode'");
                        if(!$del_mp_query){
                            echo '<script>
                                alert("Delete failed. Database deletion error");
                                window.location.href = "mpview.php";
                                </script>';
                        }
                        else{
                            echo '<script>
                            alert("Deleted Successfully");
                            window.location.href = "mpview.php";
                            </script>';
                        }
                    }
                        ?>

                    <script>

                        function rd() {
                                                    
                            let d = document.getElementById("unitprice").readOnly;
                            document.getElementById("unitprice").readOnly = !d;
                        }

                        function pricecalc(){
                            let q = document.getElementById("quantity").value;
                            let mcp = document.getElementById("mname").value;
                            
                            if(mcp!=""){
                                let up = mcp.split("*");
                                document.getElementById("unitprice").value = up[1];
                                document.getElementById("price").value = q*up[1];
                            }
                        }
                        function pricecalc2(){
                            let q = document.getElementById("quantity").value;
                            let up = document.getElementById("unitprice").value
                            if(up!=""){
                                document.getElementById("price").value = q*up;
                            }
                        }

                        function validate() {
                            let date = document.getElementById("date").value.length;
                            let billno = document.getElementById("billno").value.length;
                            let sname = document.getElementById("sname").value.length;
                            let mname = document.getElementById("mname").value.length;
                            let quantity = document.getElementById("quantity").value.length;
                            let price = document.getElementById("price").value.length;
                            let remarks = document.getElementById("remarks").value.length;
                                                        
                            if(date>10 || date==0){
                                alert("Invalid date. Please select a valid date");
                                return false;
                            }
                            if(billno>40){
                                alert("Please limit the Bill number to 40 characters");
                                return false;
                            }
                            if(billno==0){
                                alert("Please fill the Bill number before proceding further");
                                return false;
                            }
                            if(sname>12){
                                alert("Error while fetching supplier name");
                                return false;
                            }
                            if(sname==0){
                                alert("Please select the Supplier Name before proceding further");
                                return false;
                            }
                            if(mname>10){
                                alert("Error while fetching material name");
                                return false;
                            }
                            if(mname==0){
                                alert("Please select the Material before proceding further");
                                return false;
                            }
                            if(price==0){
                                alert("Price field is empty. Fill it in to proceed further");
                                return false;
                            }
                            if(price>12){
                                alert("Please limit the price field to be within 12 digits");
                                return false;
                            }
                            if(quantity==0){
                                alert("Please fill the quantity before proceding further");
                                return false;
                            }
                            if(quantity>10){
                                alert("Please limit the quantity field to be within 10 digits");
                                return false;
                            }
                            if(remarks>100){
                                alert("Please limit the remarks field to 100 characters");
                                return false;
                            }
                            
                            return true;
                        }

                    </script>

                    <!-- <div class="col-xs-6 col-sm-6">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Standard Select</strong>
                            </div>
                            <div class="card-body">

                                <select data-placeholder="Choose a Country..." class="standardSelect" tabindex="1">
                                    <option value=""></option>
                                    <option value="United States">United States</option>
                                    <option value="United Kingdom">United Kingdom</option>
                                    <option value="Afghanistan">Afghanistan</option>
                                    <option value="Aland Islands">Aland Islands</option>
                                    <option value="Albania">Albania</option>
                                    <option value="Algeria">Algeria</option>
                                    <option value="American Samoa">American Samoa</option>
                                    <option value="Andorra">Andorra</option>
                                    <option value="Angola">Angola</option>
                                    <option value="Anguilla">Anguilla</option>
                                    <option value="Antarctica">Antarctica</option>
                                </select>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Multi Select</strong>
                            </div>
                            <div class="card-body">

                                <select data-placeholder="Choose a country..." multiple class="standardSelect">
                                    <option value=""></option>
                                    <option value="United States">United States</option>
                                    <option value="United Kingdom">United Kingdom</option>
                                    <option value="Afghanistan">Afghanistan</option>
                                    <option value="Aland Islands">Aland Islands</option>
                                    <option value="Albania">Albania</option>
                                    <option value="Algeria">Algeria</option>
                                    <option value="American Samoa">American Samoa</option>
                                    <option value="Andorra">Andorra</option>
                                    <option value="Angola">Angola</option>
                                    <option value="Anguilla">Anguilla</option>
                                    <option value="Antarctica">Antarctica</option>
                                </select>

                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Multi Select with Groups</strong>
                            </div>
                            <div class="card-body">

                                <select data-placeholder="Your Favorite Football Team" multiple class="standardSelect" tabindex="5">
                                    <option value=""></option>
                                    <optgroup label="NFC EAST">
                                        <option>Dallas Cowboys</option>
                                        <option>New York Giants</option>
                                        <option>Philadelphia Eagles</option>
                                        <option>Washington Redskins</option>
                                    </optgroup>
                                    <optgroup label="NFC NORTH">
                                        <option>Chicago Bears</option>
                                        <option>Detroit Lions</option>
                                        <option>Green Bay Packers</option>
                                        <option>Minnesota Vikings</option>
                                    </optgroup>
                                    <optgroup label="NFC SOUTH">
                                        <option>Atlanta Falcons</option>
                                        <option>Carolina Panthers</option>
                                        <option>New Orleans Saints</option>
                                        <option>Tampa Bay Buccaneers</option>
                                    </optgroup>
                                    <optgroup label="NFC WEST">
                                        <option>Arizona Cardinals</option>
                                        <option>St. Louis Rams</option>
                                        <option>San Francisco 49ers</option>
                                        <option>Seattle Seahawks</option>
                                    </optgroup>
                                    <optgroup label="AFC EAST">
                                        <option>Buffalo Bills</option>
                                        <option>Miami Dolphins</option>
                                        <option>New England Patriots</option>
                                        <option>New York Jets</option>
                                    </optgroup>
                                    <optgroup label="AFC NORTH">
                                        <option>Baltimore Ravens</option>
                                        <option>Cincinnati Bengals</option>
                                        <option>Cleveland Browns</option>
                                        <option>Pittsburgh Steelers</option>
                                    </optgroup>
                                    <optgroup label="AFC SOUTH">
                                        <option>Houston Texans</option>
                                        <option>Indianapolis Colts</option>
                                        <option>Jacksonville Jaguars</option>
                                        <option>Tennessee Titans</option>
                                    </optgroup>
                                    <optgroup label="AFC WEST">
                                        <option>Denver Broncos</option>
                                        <option>Kansas City Chiefs</option>
                                        <option>Oakland Raiders</option>
                                        <option>San Diego Chargers</option>
                                    </optgroup>
                                </select>
                            </div>
                        </div>
                    </div> -->
                </div>
            </div><!-- .animated -->
        </div><!-- .content -->

    </div><!-- /#right-panel -->

    <!-- Right Panel -->

    <script>
        function winp(){
            alert("Work in Progress. Please check it out later");
        }
    </script>
<script src="vendors/jquery/dist/jquery.min.js"></script>
<script src="vendors/popper.js/dist/umd/popper.min.js"></script>
<script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="assets/js/main.js"></script>
<script src="vendors/chosen/chosen.jquery.min.js"></script>

<script>
    jQuery(document).ready(function() {
        jQuery(".standardSelect").chosen({
            disable_search_threshold: 10,
            no_results_text: "Oops, nothing found!",
            width: "100%"
        });
        
    });
</script>

</body>

</html>
