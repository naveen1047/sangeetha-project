<?php
include 'serverconfig.php';

if(isset($_GET['pcode'])){
    $pcode = trim($_GET['pcode']);

    $select_query = mysqli_query($con, "select * from product_details where pcode='$pcode'");
    if(!$select_query){
        echo '<script>
        alert("Database Retrieval Error");                                                            
        </script>'; 
        echo mysqli_error($con);
    }else{
    while($row=mysqli_fetch_array($select_query))
      {
        $pname =$row["pname"];
        $salaryps =$row["salaryps"];
        $nosps =$row["nosps"];
        $sunit =$row["sunit"];
        $pricepersunit =$row["pricepersunit"];
        $nospsunit =$row["nospsunit"];
      }
    }
}
?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Sangeetha Groups</title>
    <meta name="description" content="Sangeetha Groups">
    <meta name="mobile-web-app-capable" content="yes"><meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">


    <link rel="stylesheet" href="vendors/chosen/chosen.min.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>



</head>

<body>
    <!-- Left Panel -->

    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.html"><span style="font-family:Garamond">Sangeetha Groups</span></a>
                <a class="navbar-brand hidden" href="index.html"><img src="images/logo2.png" alt="Logo"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="index.html"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    <h3 class="menu-title">Hollow Block</h3><!-- /.menu-title -->
                    
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" 
                        aria-expanded="false"> <i class="menu-icon ti-book"></i>Material Purchase</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-pencil-square-o"></i><a href="mpentry.php">Entry</a></li>
                            <li><i class="fa  fa-book"></i><a href="mpview.php">Report</a></li>
                        </ul>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" 
                        aria-expanded="false"> <i class="menu-icon ti-agenda"></i>Production</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-pencil-square-o"></i><a href="pdentry.php">Entry</a></li>
                            <li><i class="fa  fa-book"></i><a href="pdview.php">Report</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="stockd.php"> <i class="menu-icon ti-pie-chart"></i>Stock Details </a>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" 
                        aria-expanded="false"> <i class="menu-icon ti-stats-up"></i>Sales</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-pencil-square-o"></i><a href="#" onclick="winp()">Entry</a></li>
                            <li><i class="fa  fa-book"></i><a href="#" onclick="winp()">Report</a></li>
                        </ul>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" 
                        aria-expanded="false"> <i class="menu-icon fa fa-inr"></i>Payment</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="ti-stats-up"></i><a href="#" onclick="winp()">Sales</a></li>
                            <li><i class="ti-user"></i><a href="#" onclick="winp()">Client</a></li>
                        </ul>
                    </li>
                    
                    <h3 class="menu-title">Menu</h3>
                    <li>
                        <a href="#" onclick="winp()"> <i class="menu-icon ti-settings"></i>Settings </a>
                    </li>
                    <li>
                        <a href="logout.php"> <i class="menu-icon fa fa-sign-in"></i>Logout </a>
                    </li>
                    
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                    <div class="header-left">
                            <span>  
                               <b>Current User : Mohan </b>

                            </span> 

                      
                    </div>
                </div>

                <div class="col-sm-5">
                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="images/admin.jpg" alt="User Avatar">
                        </a>

                        <div class="user-menu dropdown-menu">
                            <a class="nav-link" href="#" onclick="winp()"><i class="fa fa-user"></i> My Profile</a>

                            <a class="nav-link" href="#" onclick="winp()"><i class="fa fa-clock-o"></i> Activity History</a>

                            <a class="nav-link" href="#" onclick="winp()"><i class="fa fa-cog"></i> Settings</a>

                            <a class="nav-link" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
                        </div>
                    </div>

                    <div class="language-select dropdown" id="language-select">
                        <a  href="config.html">
                            <i class="menu-icon ti-settings"></i>
                        </a>
                        
                    </div>

                </div>
            </div>

        </header><!-- /header -->
    <!-- Header-->

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                    <h1>Edit Product &nbsp<a href="existp.php"><i class="fa fa-book"></i></a></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="index.html">Dashboard</a></li>
                            
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">

                <div class="row">

                    <div class="col-xs-6 col-sm-6" style="margin: auto;">
                        <div class="card">

                            <form method="POST" action="#" onsubmit="return validate()">
                           
                            <div class="card-body card-block">
                            <div class="form-group">
                                <label class=" form-control-label" style="color:#666; font-weight:500">Product Name</label>
                                    <div class="input-group">
                                        <input class="form-control" type="text" name="pname" id="pname"
                                        placeholder="Product Name" 
                                        value="<?php echo htmlentities($pname); ?>" required>
                                        <div class="input-group-addon"><i class="fa fa-tag"></i></div>
                                    </div>
                                   
                                </div>
                                <div class="form-group">
                                <label class=" form-control-label" style="color:#666; font-weight:500">Product Code</label>
                                    <div class="input-group">
                                        <input class="form-control" type="text" name="pcode" id="pcode"
                                        placeholder="Product Code" value="<?php echo $pcode; ?>" required readOnly>
                                        <div class="input-group-addon"><i class="fa fa-info"></i></div>
                                    </div>
                                       
                                </div>
                               
                                
                                <div class="form-group">
                                <label class=" form-control-label" style="color:#666; font-weight:500">Salary per stroke</label>
                                    <div class="input-group">
                                        <input class="form-control" type="number" name="salaryps" id="salaryps"
                                        placeholder="Salary per stroke" value="<?php echo $salaryps; ?>" required>
                                        <div class="input-group-addon"><i class="fa fa-inr"></i></div>
                                    </div>
                                       
                                </div>
                                <div class="form-group">
                                <label class=" form-control-label" style="color:#666; font-weight:500">No of Units produced per stroke</label>
                                    <div class="input-group">
                                        
                                        <input class="form-control" type="number" name="nosps" id="nosps"
                                        placeholder="Units produced per stroke" value="<?php echo $nosps; ?>" required>
                                        <div class="input-group-addon"><i class="fa fa-stack-overflow"></i></div>
                                    </div>
                                       
                                </div>
                                <div class="form-group">
                                <label class=" form-control-label" style="color:#666; font-weight:500">Selling Unit</label>
                                    <div class="input-group">
                                        
                                        <input class="form-control" type="text" name="sunit" id="sunit"
                                        placeholder="Load, unit etc" value="<?php echo $sunit; ?>" oninput="setsunit()" required>
                                        <div class="input-group-addon"><i class="fa fa-tags"></i></div>
                                    </div>
                                       
                                </div>
                                <div class="form-group">
                                <label class=" form-control-label" style="color:#666; font-weight:500">Price per <span id="ppsunit"><?php echo $sunit; ?></span></label>
                                    <div class="input-group">
                                        
                                        <input class="form-control" type="number" name="pricepersunit" id="pricepersunit"
                                        placeholder="Price per selling unit" value="<?php echo $pricepersunit; ?>" required>
                                        <div class="input-group-addon"><i class="fa fa-inr"></i></div>
                                    </div>
                                        
                                </div>
                                <div class="form-group">
                                <label class=" form-control-label" style="color:#666; font-weight:500">No of Units per <span id="lnospsunit"><?php echo $sunit; ?></span></label>
                                    <div class="input-group">
                                        
                                        <input class="form-control" type="number" name="nospsunit" id="nospsunit"
                                        placeholder="No of units per selling unit" value="<?php echo $nospsunit; ?>" required>
                                        <div class="input-group-addon"><i class="fa fa-stack-overflow"></i></div>
                                    </div>
                                       
                                </div>
                               
                                <div class="form-group">
                                    <div class="input-group">
                                        <button type="submit" name="submit" class="btn btn-success btn-block" 
                                       >Upload</button>
                                    </div>
                                </div>
                                </form>
                                <form method="POST" action="#" id="deletepform" onsubmit="return confirm('Are you sure to delete <?php echo $pname?> from your Products list?');">
                                <div class="form-group">
                                    <div class="input-group" style="margin-top:-10px">
                                        <button type="submit" name="delete" class="btn btn-danger btn-block" 
                                       >Delete</button>
                                    </div>
                                </div>
                                </form>
                                <center><b><a 
                                    href="existp.php">View existing Products</a></b></center>
                            </div>
                            
                            
                        </div>
                    </div>

                    <?php

                    if(isset($_POST["submit"])){
                        if(($_POST["pname"] != "") && ($_POST["pcode"] != "") && ($_POST["salaryps"] != "") && 
                        ($_POST["nosps"] != "") && ($_POST["sunit"] != "") && ($_POST["pricepersunit"] != "") && ($_POST["nospsunit"] != "")){
                                 
                              
                            $pname =$_POST["pname"];
                            $salaryps =$_POST["salaryps"];
                            $nosps =$_POST["nosps"];
                            $sunit =$_POST["sunit"];
                            $pricepersunit =$_POST["pricepersunit"];
                            $nospsunit =$_POST["nospsunit"];
                                                       
                            $check_duplicate = mysqli_query($con,"select * from product_details where pname='$pname' && del=''");
                            $check_duplicate_count1 = mysqli_num_rows($check_duplicate);
                            if($check_duplicate_count1>0){
                                $check_duplicate2 = mysqli_query($con,"select * from product_details where pname='$pname' && pcode='$pcode' && del=''");
                                $check_duplicate_count2 = mysqli_num_rows($check_duplicate2);
                                if($check_duplicate_count1 == $check_duplicate_count2){
                                    $update_p_query = mysqli_query($con, "update product_details set
                                     pname='$pname',
                                     salaryps='$salaryps', 
                                     nosps='$nosps', 
                                     sunit='$sunit', 
                                     pricepersunit='$pricepersunit', 
                                     nospsunit='$nospsunit' 
                                     where pcode='$pcode'");
                                    if(!$update_p_query){
                                        echo '<script>
                                        alert("Upload failed - database upload error1");                                                            
                                        </script>'; 
                                        echo mysqli_error($con);
                                    }
                                    else{
                                        echo '<script>
                                        alert("Update Success");    
                                        window.location.href = "existp.php";                                                        
                                        </script>';
                                    }

                                }else{
                                echo '<script>
                                alert("Product '.$pname.' already exists. Please Use different product");  
                                window.location.href="existp.php";                                                          
                                </script>'; 
                                }
                                
                            }else{
                                
                                $update_p_query = mysqli_query($con, "update product_details set
                                pname='$pname',
                                salaryps='$salaryps', 
                                nosps='$nosps', 
                                sunit='$sunit', 
                                pricepersunit='$pricepersunit', 
                                nospsunit='$nospsunit' 
                                where pcode='$pcode'");
                               if(!$update_p_query){
                                   echo '<script>
                                   alert("Upload failed - database upload error2");                                                            
                                   </script>'; 
                                   echo mysqli_error($con);
                               }
                               else{
                                   echo '<script>
                                   alert("Update Success");    
                                   window.location.href = "existp.php";                                                        
                                   </script>';
                               }
                            }
                         

                        }
                        else{
                            echo '
                            <script>
                            alert("Please fill in all the fields before proceeding further");
                            window.location.href="existp.php";
                            </script>
                            ';
                        }

                    }

                    ?>

<?php
                    if(isset($_POST["delete"])){
                        $del_p_query = mysqli_query($con, "update product_details set del='1' where pcode='$pcode'");
                        $del_p_fromstock_query = mysqli_query($con, "update stock_details set del='1' where pcode='$pcode'");
                        if(!$del_p_query){
                            echo '<script>
                                alert("Delete failed. Database deletion error");
                                window.location.href = "existp.php";
                                </script>';
                        }
                        else{
                            if(!$del_p_fromstock_query){
                                echo '<script>
                                alert("Delete failed - stocks table.\nBut it has been successfully deleted from product table");
                                window.location.href = "existp.php";
                                </script>';
                            }else{
                                echo '<script>
                                alert("Deleted Successfully");
                                window.location.href = "existp.php";
                                </script>';

                            }
                        }
                    }
                        ?>


               

    <script>
        
        function setsunit(){
            let sunit = document.getElementById("sunit").value;
            if(sunit!=""){
                document.getElementById("ppsunit").innerHTML= sunit;
                document.getElementById("pricepersunit").placeholder= "Price per "+sunit;
                document.getElementById("lnospsunit").innerHTML= sunit;
                document.getElementById("nospsunit").placeholder= "No of units per "+sunit;
            }else{
                document.getElementById("ppsunit").innerHTML= "selling unit";
                document.getElementById("pricepersunit").placeholder= "Price per selling unit";
                document.getElementById("lnospsunit").innerHTML= "selling unit";
                document.getElementById("nospsunit").placeholder= "No of units per selling unit";
            }
            
        }

        function validate() {
            let pname = document.getElementById("pname").value.length;
            let pcode = document.getElementById("pcode").value.length;
            let salaryps = document.getElementById("salaryps").value.length;
            let nosps = document.getElementById("nosps").value.length;
            let sunit = document.getElementById("sunit").value.length;
            let pricepersunit = document.getElementById("pricepersunit").value.length;
            let nospsunit = document.getElementById("nospsunit").value.length;

            if(pname>30){
                alert("Please limit the Product Name within 30 characters");
                return false;
            }
            if(pname==0){
                alert("Please fill in the Product name");
                return false;
            }
            if(pcode>10){
                alert("Please don't use More than 7 words or 30 characters in the Product Name");
                return false;
            }
            if(pcode==0){
                alert("Product code not generated. please try again");
                window.location.href="addp.php";
                return false;
            }
            if(salaryps>10){
                alert("Please limit the salary per stroke within 10 digits");
                return false;
            }
            if(salaryps==0){
                alert("Please fill in the salary per stroke");
                return false;
            }
            if(nosps>10){
                alert("Please limit the No of units produced per stroke within 10 digits");
                return false;
            }
            if(nosps==0){
                alert("Please fill in the No of units produced per stroke");
                return false;
            }
            if(sunit>10){
                alert("Please limit the selling unit within 15 characters");
                return false;
            }
            if(sunit==0){
                alert("Please fill in the selling unit");
                return false;
            }
            if(pricepersunit>10){
                alert("Please limit the price per selling unit within 10 digits");
                return false;
            }
            if(pricepersunit==0){
                alert("Please fill in the price per selling unit");
                return false;
            }
            if(nospsunit>10){
                alert("Please limit the No of units per selling unit within 10 digits");
                return false;
            }
            if(nospsunit==0){
                alert("Please fill in the No of units per selling unit");
                return false;
            }

            return true;
        }
        
    </script>

                    <!-- <div class="col-xs-6 col-sm-6">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Standard Select</strong>
                            </div>
                            <div class="card-body">

                                <select data-placeholder="Choose a Country..." class="standardSelect" tabindex="1">
                                    <option value=""></option>
                                    <option value="United States">United States</option>
                                    <option value="United Kingdom">United Kingdom</option>
                                    <option value="Afghanistan">Afghanistan</option>
                                    <option value="Aland Islands">Aland Islands</option>
                                    <option value="Albania">Albania</option>
                                    <option value="Algeria">Algeria</option>
                                    <option value="American Samoa">American Samoa</option>
                                    <option value="Andorra">Andorra</option>
                                    <option value="Angola">Angola</option>
                                    <option value="Anguilla">Anguilla</option>
                                    <option value="Antarctica">Antarctica</option>
                                </select>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Multi Select</strong>
                            </div>
                            <div class="card-body">

                                <select data-placeholder="Choose a country..." multiple class="standardSelect">
                                    <option value=""></option>
                                    <option value="United States">United States</option>
                                    <option value="United Kingdom">United Kingdom</option>
                                    <option value="Afghanistan">Afghanistan</option>
                                    <option value="Aland Islands">Aland Islands</option>
                                    <option value="Albania">Albania</option>
                                    <option value="Algeria">Algeria</option>
                                    <option value="American Samoa">American Samoa</option>
                                    <option value="Andorra">Andorra</option>
                                    <option value="Angola">Angola</option>
                                    <option value="Anguilla">Anguilla</option>
                                    <option value="Antarctica">Antarctica</option>
                                </select>

                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Multi Select with Groups</strong>
                            </div>
                            <div class="card-body">

                                <select data-placeholder="Your Favorite Football Team" multiple class="standardSelect" tabindex="5">
                                    <option value=""></option>
                                    <optgroup label="NFC EAST">
                                        <option>Dallas Cowboys</option>
                                        <option>New York Giants</option>
                                        <option>Philadelphia Eagles</option>
                                        <option>Washington Redskins</option>
                                    </optgroup>
                                    <optgroup label="NFC NORTH">
                                        <option>Chicago Bears</option>
                                        <option>Detroit Lions</option>
                                        <option>Green Bay Packers</option>
                                        <option>Minnesota Vikings</option>
                                    </optgroup>
                                    <optgroup label="NFC SOUTH">
                                        <option>Atlanta Falcons</option>
                                        <option>Carolina Panthers</option>
                                        <option>New Orleans Saints</option>
                                        <option>Tampa Bay Buccaneers</option>
                                    </optgroup>
                                    <optgroup label="NFC WEST">
                                        <option>Arizona Cardinals</option>
                                        <option>St. Louis Rams</option>
                                        <option>San Francisco 49ers</option>
                                        <option>Seattle Seahawks</option>
                                    </optgroup>
                                    <optgroup label="AFC EAST">
                                        <option>Buffalo Bills</option>
                                        <option>Miami Dolphins</option>
                                        <option>New England Patriots</option>
                                        <option>New York Jets</option>
                                    </optgroup>
                                    <optgroup label="AFC NORTH">
                                        <option>Baltimore Ravens</option>
                                        <option>Cincinnati Bengals</option>
                                        <option>Cleveland Browns</option>
                                        <option>Pittsburgh Steelers</option>
                                    </optgroup>
                                    <optgroup label="AFC SOUTH">
                                        <option>Houston Texans</option>
                                        <option>Indianapolis Colts</option>
                                        <option>Jacksonville Jaguars</option>
                                        <option>Tennessee Titans</option>
                                    </optgroup>
                                    <optgroup label="AFC WEST">
                                        <option>Denver Broncos</option>
                                        <option>Kansas City Chiefs</option>
                                        <option>Oakland Raiders</option>
                                        <option>San Diego Chargers</option>
                                    </optgroup>
                                </select>
                            </div>
                        </div>
                    </div> -->
                </div>
            </div><!-- .animated -->
        </div><!-- .content -->

        

    </div><!-- /#right-panel -->

    <!-- Right Panel -->


    <script>
        function winp(){
            alert("Work in Progress. Please check it out later");
        }
    </script>
<script src="vendors/jquery/dist/jquery.min.js"></script>
<script src="vendors/popper.js/dist/umd/popper.min.js"></script>
<script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="assets/js/main.js"></script>
<script src="vendors/chosen/chosen.jquery.min.js"></script>

<script>
    jQuery(document).ready(function() {
        jQuery(".standardSelect").chosen({
            disable_search_threshold: 10,
            no_results_text: "Oops, nothing found!",
            width: "100%"
        });
    });
</script>

</body>

</html>
