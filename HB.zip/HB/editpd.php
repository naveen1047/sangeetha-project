<?php
include 'serverconfig.php';
if(isset($_GET['pdcode'])){
    $pdcode = trim($_GET['pdcode']);

    $select_query = mysqli_query($con, "select * from production_details where pdcode='$pdcode'");
    if(!$select_query){
        echo '<script>
        alert("Database Retrieval Error");                                                            
        </script>'; 
        echo mysqli_error($con);
    }else{
    while($rowmp=mysqli_fetch_array($select_query))
      {
        $date = $rowmp["date"];
        $pcode = $rowmp["pcode"];
        $ecode = $rowmp["ecode"];
        $sps = $rowmp["sps"];
        $nos = $rowmp["nos"];
        $nosps = $rowmp["nosps"];
        $salary  = $rowmp["salary"];
        $remarks = $rowmp["remarks"];
      }
    }
}
?>

<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Sangeetha Groups</title>
    <meta name="description" content="Sangeetha Groups">
    <meta name="mobile-web-app-capable" content="yes"><meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">


    <link rel="stylesheet" href="vendors/chosen/chosen.min.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>



</head>

<body>
    <!-- Left Panel -->
    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.html"><span style="font-family:Garamond">Sangeetha Groups</span></a>
                <a class="navbar-brand hidden" href="index.html"><img src="images/logo2.png" alt="Logo"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="index.html"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    <h3 class="menu-title">Hollow Block</h3><!-- /.menu-title -->
                    
                    <li class="menu-item-has-children dropdown ">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" 
                        aria-expanded="false"> <i class="menu-icon ti-book"></i>Material Purchase</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-pencil-square-o"></i><a href="mpentry.php">Entry</a></li>
                            <li><i class="fa  fa-book"></i><a href="mpview.php">Report</a></li>
                        </ul>
                    </li>
                    <li class="menu-item-has-children dropdown active">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" 
                        aria-expanded="false"> <i class="menu-icon ti-agenda"></i>Production</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-pencil-square-o"></i><a href="pdentry.php">Entry</a></li>
                            <li><i class="fa  fa-book"></i><a href="pdview.php">Report</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="stockd.php"> <i class="menu-icon ti-pie-chart"></i>Stock Details </a>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" 
                        aria-expanded="false"> <i class="menu-icon ti-stats-up"></i>Sales</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-pencil-square-o"></i><a href="#" onclick="winp()">Entry</a></li>
                            <li><i class="fa  fa-book"></i><a href="#" onclick="winp()">Report</a></li>
                        </ul>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" 
                        aria-expanded="false"> <i class="menu-icon fa fa-inr"></i>Payment</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="ti-stats-up"></i><a href="#" onclick="winp()">Sales</a></li>
                            <li><i class="ti-user"></i><a href="#" onclick="winp()">Client</a></li>
                        </ul>
                    </li>
                    
                    <h3 class="menu-title">Menu</h3>
                    <li>
                        <a href="#" onclick="winp()"> <i class="menu-icon ti-settings"></i>Settings </a>
                    </li>
                    <li>
                        <a href="logout.php"> <i class="menu-icon fa fa-sign-in"></i>Logout </a>
                    </li>
                    
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                    <div class="header-left">
                            <span>  
                               <b>Current User : Mohan </b>

                            </span> 

                      
                    </div>
                </div>

                <div class="col-sm-5">
                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="images/admin.jpg" alt="User Avatar">
                        </a>

                        <div class="user-menu dropdown-menu">
                            <a class="nav-link" href="#" onclick="winp()"><i class="fa fa-user"></i> My Profile</a>

                            <a class="nav-link" href="#" onclick="winp()"><i class="fa fa-clock-o"></i> Activity History</a>

                            <a class="nav-link" href="#" onclick="winp()"><i class="fa fa-cog"></i> Settings</a>

                            <a class="nav-link" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
                        </div>
                    </div>

                    <div class="language-select dropdown" id="language-select">
                        <a  href="config.html">
                            <i class="menu-icon ti-settings"></i>
                        </a>
                        
                    </div>

                </div>
            </div>

        </header><!-- /header -->
    <!-- Header-->
        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Edit Production details &nbsp<a href="pdview.php"><i class="fa fa-book"></i></a></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="index.html">Dashboard</a></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">

                <div class="row">

                    <div class="col-xs-6 col-sm-6" style="margin: auto;">
                        <div class="card">
                            
                        <form method="POST" action="#" id="addpdentryform" onsubmit="return validate()">
                            <div class="card-body card-block">
                                <div class="form-group">
                                <label class=" form-control-label" style="color:#666; font-weight:500">Date</label>
                                    <div class="input-group">
                                        <div class="input-group-addon"><i class="fa fa-calendar"></i></div>
                                        <input class="form-control" type="date" name="date" id="date" 
                                        value="<?php echo $date; ?>" required>
                                    </div>
                                   
                                </div>
                                <div class="form-group">
                                <label class=" form-control-label" style="color:#666; font-weight:500">Product Name</label>
                                    <div class="input-group">
                                       
                                        <select data-placeholder="Product" class="standardSelect" tabindex="1"
                                        name="pcode" id="pcode" style="width:100%" onchange="pselected()" required>
                                        <option value="option1" disabled hidden selected></option>

                                        <?php
                                        $fetch_products = mysqli_query($con, "select * from product_details where del=''");
                                        if(!$fetch_products){
                                        echo '
                                        <script>
                                            alert("database connectivity error);
                                        </script>
                                        ';
                                        echo mysqli_error($con);
                                        }else{
                                        if(mysqli_num_rows($fetch_products)<=0){

                                            ?>
                                        <option value="option2">No Products found. Click here to add products<option>
                                            <?php
                                            }else{
                                        while($row2=mysqli_fetch_array($fetch_products)){
                                            $pcodeforstock = $row2['pcode'];
                                            $fetch_tstock = mysqli_query($con, "select tstock from stock_details where pcode='$pcodeforstock' && del=''");
                                            if(!$fetch_tstock){
                                            echo '
                                            <script>
                                                alert("database connectivity error);
                                            </script>
                                            ';
                                            echo mysqli_error($con);
                                            }else{
                                                $tstockf = "t";
                                                while($srow=mysqli_fetch_array($fetch_tstock)){
                                                    $tstockf = $srow["tstock"];
                                            }
                                            }
                                        ?>
                                        <option <?php echo ($row2['pcode'] == $pcode)?"selected":""; ?>  
                                          value="<?php echo $row2['pcode']."#".$row2['salaryps']."#".$row2['nosps']."#".$tstockf; ?>"><?php echo $row2['pname']; ?></option>
                                        <?php
                                        }
                                        }
                                        }
                                        ?>
                                        </select>
                                    </div>
                                   
                                </div>
                               
                                <div class="form-group">
                                <label class=" form-control-label" style="color:#666; font-weight:500">Team Name</label>
                                    <div class="input-group">
                                       
                                        <select data-placeholder="Team Name" class="standardSelect" tabindex="1" 
                                        name="ecode" id="ecode" style="width:100%" readonly >
                                        <option value="option1" disabled hidden selected></option>

                                        <?php
                                        $fetch_employee = mysqli_query($con, "select * from employee_details where del=''");
                                        if(!$fetch_employee){
                                        echo '
                                        <script>
                                            alert("database connectivity error);
                                        </script>
                                        ';
                                        echo mysqli_error($con);
                                        }else{
                                        if(mysqli_num_rows($fetch_employee)<=0){

                                            ?>
                                        <option value="option2">No employee found. Click here to add employees<option>
                                            <?php
                                            }else{
                                        while($row3=mysqli_fetch_array($fetch_employee)){
                                        ?>
                                        <option <?php echo ($row3['ecode'] == $ecode)?"selected":""; ?> 
                                         value="<?php echo $row3['ecode']; ?>"><?php echo $row3['ename']." - ".$row3['ecode']; ?></option>
                                        <?php
                                        }
                                        }
                                        }
                                        ?>
                                        </select>
                                    </div>
                                   
                                </div>
                                 <div class="form-group">
                                 <label class=" form-control-label" style="color:#666; font-weight:500">Salary per stroke</label>
                                    <div class="input-group">
                                        <div class="input-group-addon"><i class="fa fa-inr"></i></div>
                                        <input class="form-control" type="Number" name="sps" id="sps" readOnly
                                        placeholder="Salary per Stroke" value="<?php echo $sps; ?>" oninput="nosinput()" >
                                        <div class="input-group-addon" id="rd" onclick="rd()"><i class="fa fa-pencil"></i></div>
                                    </div>
                                       
                                </div>
                                <div class="form-group">
                                 <label class=" form-control-label" style="color:#666; font-weight:500">Units produced per stroke</label>
                                    <div class="input-group">
                                        <div class="input-group-addon"><i class="fa fa-tasks"></i></div>
                                        <input class="form-control" type="Number" name="nosps" id="nosps" readOnly
                                        placeholder="Units produced per stroke" oninput="nosinput()" 
                                        value="<?php echo $nosps ?>" required>
                                        <div class="input-group-addon" id="rd1" onclick="rd1()"><i class="fa fa-pencil"></i></div>
                                    </div>
                                       
                                </div>
                                
                                 <div class="form-group">
                                 <label class=" form-control-label" style="color:#666; font-weight:500">Number of stroke</label>
                                    <div class="input-group">
                                        <div class="input-group-addon"><i class="fa fa-refresh"></i></div>
                                        <input class="form-control" type="Number" name="nos" id="nos" 
                                        oninput="nosinput()" required value="<?php echo $nos; ?>"
                                        placeholder="Number of strokes">
                                    </div>


                                    <div style="text-align:right; font-size:14px;font-weight:500; color:green;" id="cstockdiv">
                                            Current Stock : <span id="cstockplus"></span><span id="cstockadd"></span>
                                            <span id="calc" style="color:#666"></span>
                                            
                                    </div>
                                       
                                </div>
                                <div class="form-group">
                                <label class=" form-control-label" style="color:#666; font-weight:500">Salary</label>
                                    <div class="input-group">
                                        <div class="input-group-addon"><i class="fa fa-inr"></i></div>
                                        <input class="form-control" placeholder="Salary" name="salary" id="salary" value="<?php echo $salary; ?>" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                <label class=" form-control-label" style="color:#666; font-weight:500">Remarks</label>
                                    <div class="input-group">
                                        <textarea name="remarks" id="remarks" 
                                        rows="2" placeholder="Remarks" class="form-control"><?php echo $remarks; ?></textarea>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="input-group">
                                        <button type="submit" name="submit" class="btn btn-success btn-block" 
                                       >Update</button>
                                    </div>
                                </div>

                               
                               

                               <input type="text" id="pdcode" name="pdcode" style="height: 1px;width: 5px;visibility: hidden;display:inline" value="<?php echo $pdcode; ?>">
                               <input type="text" id="cstock" name="cstock" style="height: 1px;width: 5px;visibility: hidden;display:inline">
                               <input type="text" id="rstock" name="rstock" style="height: 1px;width: 5px;visibility: hidden;display:inline">
                               <input type="text" id="tstock" name="tstock" style="height: 1px;width: 5px;visibility: hidden;display:inline">
                               <input type="text" id="nospsh" name="nospsh" style="height: 1px;width: 5px;visibility: hidden;display:inline" value="<?php echo $nosps; ?>">
                               <input type="text" id="nosh" name="nosh" style="height: 1px;width: 5px;visibility: hidden;display:inline" value="<?php echo $nos; ?>">
                           
                               </form>
                               <form method="POST" action="#" onsubmit="return confirm('Are you sure to delete this record from your Production details report?');">
                               <div class="form-group" style="margin-top:-30px">
                                    <div class="input-group">
                                        <button type="submit" name="delete" class="btn btn-danger btn-block" 
                                       >Delete</button>
                                    </div>
                                </div>
                                </form> 
                                
                                <center><b><a 
                                    href="pdview.php">View Production Report</a></b></center>
                            </div>
                        
                        
                        </div>
                    </div>

                    <?php

if(isset($_POST["submit"])){
    if(($_POST["date"] != "") && ($_POST["pdcode"] != "") && ($_POST["pcode"] != "") && 
    ($_POST["ecode"] != "") && ($_POST["sps"] != "") && ($_POST["nos"] != "") && ($_POST["salary"] != "")
    && ($_POST["cstock"] != "")&& ($_POST["rstock"] != "")&& ($_POST["tstock"] != "")){

                    
                    $date = $_POST["date"];
                    $pdcode = $_POST["pdcode"];
                    $ecode = $_POST["ecode"];
                    $pcode = $_POST["pcode"];
                    $pcode2 = explode("#",$pcode);
                    $sps = $_POST["sps"];
                    $nos = $_POST["nos"];
                    $salary = $_POST["salary"];
                    $remarks = $_POST["remarks"];
                    $cstock = $_POST["cstock"];
                    $rstock = $_POST["rstock"];
                    $tstock = $_POST["tstock"];

                    $update_pd_query = mysqli_query($con, "update production_details 
                    set date='$date',
                    pcode='$pcode2[0]',
                    ecode='$ecode',
                    sps='$sps',
                    nos='$nos',
                    nosps='$nosps',
                    salary='$salary',
                    remarks='$remarks' where pdcode = '$pdcode'");
                    
                                       
                    $update_stock = mysqli_query($con, "update stock_details set 
                    cstock='$cstock',
                    rstock='$rstock',
                    tstock='$tstock' where pcode='$pcode2[0]' ");
                            if(!$update_pd_query){
                                echo '<script>
                                alert("Upload failed - database upload error");                                                            
                                </script>'; 
                                echo mysqli_error($con);
                            }
                            else{
                                if(!$update_stock){
                                    echo '<script>
                                alert("Upload failed in stocks table - But has been success in production table");                                                            
                                </script>'; 
                                echo mysqli_error($con);

                                }else{
                                    echo '<script>
                                    alert("Upload Success");    
                                    window.location.href = "pdview.php";                                                        
                                    </script>';
                                    
                                }
                            }

                
    }
    else{
        echo '
        <script>
        alert("Please fill in all the fields before proceeding further");
        window.location.href="pdentry.php";
        </script>
        ';
    }
}
?>

<?php
                    if(isset($_POST["delete"])){
                        $del_pd_query = mysqli_query($con, "update production_details set del='1' where pdcode='$pdcode'");
                        $rstockcalc = (float)$nos * (float)$nosps ;
                        $rstockcalcn = "-".((float)$nos * (float)$nosps) ;
                        $tstockcalc = (float)$tstockf - $rstockcalc;
                        $update_stock_ondel = mysqli_query($con, "update stock_details set cstock='$tstockf', rstock ='$rstockcalcn', tstock='$tstockcalc' where pcode='$pcode'");
                        if(!$del_pd_query){
                            echo '<script>
                                alert("Delete failed. Database deletion error");
                                window.location.href = "pdview.php";
                                </script>';
                        }
                        else{
                            echo '<script>
                            alert("Deleted Successfully");
                            window.location.href = "pdview.php";
                            </script>';
                        }
                    }
                        ?>
  
                    <script>

                        function rd() {
                            
                            let d = document.getElementById("sps").readOnly;
                            document.getElementById("sps").readOnly = !d;
                        }
                        function rd1() {
                            let d1 = document.getElementById("nosps").readOnly;
                            document.getElementById("nosps").readOnly = !d1;
                        }
                        pselected();
                        function pselected(){

                            let pcvalue = document.getElementById("pcode").value;
                            let pcarr = pcvalue.split("#");
                            document.getElementById("sps").value = pcarr[1];
                            document.getElementById("cstockdiv").style.display = "block";
                            document.getElementById("cstockplus").innerHTML = pcarr[3];
                            document.getElementById("cstock").value = pcarr[3];

                            document.getElementById("nos").addEventListener("mousewheel", function(event){ this.blur() })
                            document.getElementById("sps").addEventListener("mousewheel", function(event){ this.blur() })
                            document.getElementById("nosps").addEventListener("mousewheel", function(event){ this.blur() })
                            document.getElementById("salary").addEventListener("mousewheel", function(event){ this.blur() })

                            let op = document.getElementById("pcode").value;
                            if(op == "option2"){
                                window.location.href="addp.php";
                            }
                               
                            let nos = document.getElementById("nos").value;
                            if(nos!=""){
                                nosinput();
                            }
                        }
                        function nosinput(){
                            let pcvalue = document.getElementById("pcode").value;
                                let nos = document.getElementById("nos").value;
                                let nosh = document.getElementById("nosh").value;
                                let nospsh = document.getElementById("nospsh").value;
                                let pcarr = pcvalue.split("#");
                            if(pcvalue!="option1" && nos!=""){

                                let nosps = document.getElementById("nosps").value;
                                let ostock =  Number(nosh) * Number(nospsh);
                                let nstock =  Number(nosps)*Number(nos);
                                document.getElementById("cstockadd").innerHTML = " + "+(nstock - ostock);
                                document.getElementById("rstock").value = nstock - ostock;
                                document.getElementById("tstock").value = Number(document.getElementById("cstock").value) + Number(document.getElementById("rstock").value);

                                document.getElementById("salary").value = Number(document.getElementById("sps").value)*nos;
                                document.getElementById("calc").innerHTML = " (" + (nstock - ostock) + " = " +nstock+ " - " + ostock +")"  ;
                            }
                        }
                        
                        function validate() {
                            let date = document.getElementById("date").value.length;
                            let pcode = document.getElementById("pcode").value.length;
                            let pcvalue = document.getElementById("pcode").value;
                            let pcarr = pcvalue.split("#");
                            let ecode = document.getElementById("ecode").value.length;
                            let sps = document.getElementById("sps").value.length;
                            let nos = document.getElementById("nos").value.length;
                            let nosps = document.getElementById("nosps").value.length;
                            let salary = document.getElementById("salary").value.length;
                            let remarks = document.getElementById("remarks").value.length;
                            let pdcode = document.getElementById("pdcode").value.length;
                            let cstock = document.getElementById("cstock").value.length;
                            let rstock = document.getElementById("rstock").value.length;
                            let tstock = document.getElementById("tstock").value.length;

                            if(document.getElementById("pcode").value =="option1"){
                                alert("Please select the Product");
                                return false;
                            }
                            if(document.getElementById("pcode").value =="option2"){
                                alert("No products found. Click Ok to add products");
                                window.location.href="addp.php";
                                return false;
                            }
                            
                            if(document.getElementById("ecode").value =="option1"){
                                alert("Please select the Team name");
                                return false;
                            }
                            if(document.getElementById("ecode").value =="option2"){
                                alert("No employee details found. Click Ok to add Employee");
                                window.location.href="adds.php";
                                return false;
                            }

                            if(date>10 || date==0){
                                alert("Invalid date. Please select a valid date");
                                return false;
                            }
                            if(sps>10){
                                alert("Please limit the Salary per stroke within 10 digits");
                                return false;
                            }
                            if(sps==0){
                                alert("Please fill in the Salary per stroke before proceding further");
                                return false;
                            }
                            if(nosps>12){
                                alert("Please limit the Units produced per stroke within 12 digits");
                                return false;
                            }
                            if(nosps==0){
                                alert("Please fill in the Units produced per stroke before proceding further");
                                return false;
                            }
                            if(pcarr[0]>12){
                                alert("Error while fetching Product name");
                                return false;
                            }
                            if(pcarr[0]==0){
                                alert("Please select the Supplier Name before proceding further");
                                return false;
                            }
                            if(ecode>12){
                                alert("Error while fetching Team name");
                                return false;
                            }
                            if(ecode==0){
                                alert("Please select the Team before proceding further");
                                return false;
                            }
                            if(nos==0){
                                alert("No of strokes field is empty. Fill it in to proceed further");
                                return false;
                            }
                            if(nos>10){
                                alert("Please limit the No of strokes field to be within 12 digits");
                                return false;
                            }
                            if(salary==0){
                                alert("Salary field is empty. Fill it in to proceed further");
                                return false;
                            }
                            if(salary>10){
                                alert("Please limit the salary field to be within 10 digits");
                                return false;
                            }
                            
                            if(remarks>100){
                                alert("Please limit the remarks field to 100 characters");
                                return false;
                            }
                            if(pdcode==0){
                                pdcodegen();
                                let pdcode2 = document.getElementById("pdcode").value.length;
                                if(pdcode2==0){
                                    alert("PDCode not generated. Please try again");
                                    return false;
                                }
                            }
                            if(pdcode>10){
                                    alert("PDCode generation error. Please try again");
                                    return false;
                                }
                            if(cstock == 0){
                                alert("Current Stock is not fetched. Please try again");
                                    return false
                            }
                            if(cstock > 15){
                                alert("Current Stock field has exceeded its range - 15. Please try again");
                                    return false
                            }
                            if(rstock == 0){
                                alert("Recent Stock is not fetched. Please try again");
                                    return false
                            }
                            if(rstock > 15){
                                alert("Recent Stock field has exceeded its range - 15. Please try again");
                                    return false
                            }
                            if(tstock == 0){
                                alert("Total Stock is not fetched. Please try again");
                                    return false
                            }
                            if(tstock > 15){
                                alert("Total Stock field has exceeded its range - 15. Please try again");
                                    return false
                            }
                            return true;
                        }
                    </script>

                    <!-- <div class="col-xs-6 col-sm-6">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Standard Select</strong>
                            </div>
                            <div class="card-body">

                                <select data-placeholder="Choose a Country..." class="standardSelect" tabindex="1">
                                    <option value=""></option>
                                    <option value="United States">United States</option>
                                    <option value="United Kingdom">United Kingdom</option>
                                    <option value="Afghanistan">Afghanistan</option>
                                    <option value="Aland Islands">Aland Islands</option>
                                    <option value="Albania">Albania</option>
                                    <option value="Algeria">Algeria</option>
                                    <option value="American Samoa">American Samoa</option>
                                    <option value="Andorra">Andorra</option>
                                    <option value="Angola">Angola</option>
                                    <option value="Anguilla">Anguilla</option>
                                    <option value="Antarctica">Antarctica</option>
                                </select>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Multi Select</strong>
                            </div>
                            <div class="card-body">

                                <select data-placeholder="Choose a country..." multiple class="standardSelect">
                                    <option value=""></option>
                                    <option value="United States">United States</option>
                                    <option value="United Kingdom">United Kingdom</option>
                                    <option value="Afghanistan">Afghanistan</option>
                                    <option value="Aland Islands">Aland Islands</option>
                                    <option value="Albania">Albania</option>
                                    <option value="Algeria">Algeria</option>
                                    <option value="American Samoa">American Samoa</option>
                                    <option value="Andorra">Andorra</option>
                                    <option value="Angola">Angola</option>
                                    <option value="Anguilla">Anguilla</option>
                                    <option value="Antarctica">Antarctica</option>
                                </select>

                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Multi Select with Groups</strong>
                            </div>
                            <div class="card-body">

                                <select data-placeholder="Your Favorite Football Team" multiple class="standardSelect" tabindex="5">
                                    <option value=""></option>
                                    <optgroup label="NFC EAST">
                                        <option>Dallas Cowboys</option>
                                        <option>New York Giants</option>
                                        <option>Philadelphia Eagles</option>
                                        <option>Washington Redskins</option>
                                    </optgroup>
                                    <optgroup label="NFC NORTH">
                                        <option>Chicago Bears</option>
                                        <option>Detroit Lions</option>
                                        <option>Green Bay Packers</option>
                                        <option>Minnesota Vikings</option>
                                    </optgroup>
                                    <optgroup label="NFC SOUTH">
                                        <option>Atlanta Falcons</option>
                                        <option>Carolina Panthers</option>
                                        <option>New Orleans Saints</option>
                                        <option>Tampa Bay Buccaneers</option>
                                    </optgroup>
                                    <optgroup label="NFC WEST">
                                        <option>Arizona Cardinals</option>
                                        <option>St. Louis Rams</option>
                                        <option>San Francisco 49ers</option>
                                        <option>Seattle Seahawks</option>
                                    </optgroup>
                                    <optgroup label="AFC EAST">
                                        <option>Buffalo Bills</option>
                                        <option>Miami Dolphins</option>
                                        <option>New England Patriots</option>
                                        <option>New York Jets</option>
                                    </optgroup>
                                    <optgroup label="AFC NORTH">
                                        <option>Baltimore Ravens</option>
                                        <option>Cincinnati Bengals</option>
                                        <option>Cleveland Browns</option>
                                        <option>Pittsburgh Steelers</option>
                                    </optgroup>
                                    <optgroup label="AFC SOUTH">
                                        <option>Houston Texans</option>
                                        <option>Indianapolis Colts</option>
                                        <option>Jacksonville Jaguars</option>
                                        <option>Tennessee Titans</option>
                                    </optgroup>
                                    <optgroup label="AFC WEST">
                                        <option>Denver Broncos</option>
                                        <option>Kansas City Chiefs</option>
                                        <option>Oakland Raiders</option>
                                        <option>San Diego Chargers</option>
                                    </optgroup>
                                </select>
                            </div>
                        </div>
                    </div> -->
                </div>
            </div><!-- .animated -->
        </div><!-- .content -->

    </div><!-- /#right-panel -->

    <!-- Right Panel -->
    <script>
        function winp(){
            alert("Work in Progress. Please check it out later");
        }
    </script>

<script src="vendors/jquery/dist/jquery.min.js"></script>
<script src="vendors/popper.js/dist/umd/popper.min.js"></script>
<script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="assets/js/main.js"></script>
<script src="vendors/chosen/chosen.jquery.min.js"></script>

<script>
    jQuery(document).ready(function() {
        jQuery(".standardSelect").chosen({
            disable_search_threshold: 10,
            no_results_text: "Oops, nothing found!",
            width: "100%"
        });
    });
</script>

</body>

</html>
