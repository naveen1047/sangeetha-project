<?php
//database name
$database_name = "sangeethagroups";

//User: root@localhost --> (host name / IP address, MYSQL Username, MYSQL Password)
$con = mysqli_connect("localhost","root","");

//check whether the connection to the server is successful
if(!$con){
    die("Initial Server Connection Error : ".mysql_eror());
}

//select the required database
mysqli_select_db($con, $database_name);
?>