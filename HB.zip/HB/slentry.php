<?php
include 'serverconfig.php';
?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Sangeetha Groups</title>
    <meta name="description" content="Sangeetha Groups">
    <meta name="mobile-web-app-capable" content="yes"><meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">


    <link rel="stylesheet" href="vendors/chosen/chosen.min.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>



</head>

<body>
    <!-- Left Panel -->
    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.html"><span style="font-family:Garamond">Sangeetha Groups</span></a>
                <a class="navbar-brand hidden" href="index.html"><img src="images/logo2.png" alt="Logo"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li >
                        <a href="index.html"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    <h3 class="menu-title">Hollow Block</h3><!-- /.menu-title -->
                    
                    <li class="menu-item-has-children dropdown" >
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" 
                        aria-expanded="false"> <i class="menu-icon ti-book"></i>Material Purchase</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-pencil-square-o"></i><a href="mpentry.php">Entry</a></li>
                            <li><i class="fa  fa-book"></i><a href="mpview.php">Report</a></li>
                        </ul>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" 
                        aria-expanded="false"> <i class="menu-icon ti-agenda"></i>Production</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-pencil-square-o"></i><a href="pdentry.php">Entry</a></li>
                            <li><i class="fa  fa-book"></i><a href="pdview.php">Report</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="stockd.php"> <i class="menu-icon ti-pie-chart"></i>Stock Details </a>
                    </li>
                    <li class="menu-item-has-children dropdown active">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" 
                        aria-expanded="false"> <i class="menu-icon ti-stats-up"></i>Sales</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-pencil-square-o"></i><a href="slentry.php">Entry</a></li>
                            <li><i class="fa  fa-book"></i><a href="slview.php">Report</a></li>
                        </ul>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" 
                        aria-expanded="false"> <i class="menu-icon fa fa-inr"></i>Payment</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="ti-stats-up"></i><a href="#" onclick="winp()">Sales</a></li>
                            <li><i class="ti-user"></i><a href="#" onclick="winp()">Client</a></li>
                        </ul>
                    </li>
                    
                    <h3 class="menu-title">Menu</h3>
                    <li>
                        <a href="#" onclick="winp()"> <i class="menu-icon ti-settings"></i>Settings </a>
                    </li>
                    <li>
                        <a href="logout.php"> <i class="menu-icon fa fa-sign-in"></i>Logout </a>
                    </li>
                    
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                    <div class="header-left">
                            <span>  
                               <b>Current User : Mohan </b>

                            </span> 

                      
                    </div>
                </div>

                <div class="col-sm-5">
                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="images/admin.jpg" alt="User Avatar">
                        </a>

                        <div class="user-menu dropdown-menu">
                            <a class="nav-link" href="#" onclick="winp()"><i class="fa fa-user"></i> My Profile</a>

                            <a class="nav-link" href="#" onclick="winp()"><i class="fa fa-clock-o"></i> Activity History</a>

                            <a class="nav-link" href="#" onclick="winp()"><i class="fa fa-cog"></i> Settings</a>

                            <a class="nav-link" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
                        </div>
                    </div>

                    <div class="language-select dropdown" id="language-select">
                        <a  href="config.html">
                            <i class="menu-icon ti-settings"></i>
                        </a>
                        
                    </div>

                </div>
            </div>

        </header><!-- /header -->
    <!-- Header-->

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Sales Entry &nbsp<a href="slview.php"><i class="fa fa-book"></i></a></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="index.html">Dashboard</a></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">

                <div class="row">

                    <div class="col-xs-6 col-sm-6" style="margin: auto;">
                        <div class="card">
                        <form method="POST" action="#" id="salesentryform" onsubmit="return validate()">
                           
                            <div class="card-body card-block">
                            <div class="form-group">
                                <label class=" form-control-label" style="color:#666; font-weight:500">Date</label>
                                    <div class="input-group" data-toggle="tooltip" data-placement="top" title="Date">
                                        <div class="input-group-addon"><i class="fa fa-calendar"></i></div>
                                        <input class="form-control" type="date" name="date" id="date"  required>
                                    </div>
                                   
                                </div>


                            <div class="form-group">
                            <label class=" form-control-label" style="color:#666; font-weight:500">Customer Name</label>
                                <div class="input-group" >
                                   
                                    <select data-placeholder="Customer Name" class="standardSelect" tabindex="1"
                                    name="cname" id="cname" onchange="slcodegen()" style="width:100%" required>
                                    <option value="option1" disabled selected>Customer Name</option>

                                    <?php
                                    $fetch_customer = mysqli_query($con, "select ccode, cname,amountbl from customer_details where del =''");
                                    if(!$fetch_customer){
                                        echo '
                                        <script>
                                            alert("database connectivity error);
                                        </script>
                                        ';
                                        echo mysqli_error($con);
                                    }else{

                                        if(mysqli_num_rows($fetch_customer)<=0){
                                            ?>
                                        <option value="option2" >No customers found. Click here to add customer</option>
                                       <?php     
                                        }else{
                                    while($row1=mysqli_fetch_array($fetch_customer)){
                                        ?>
                                        <option value="<?php echo $row1['ccode']."*".$row1['amountbl']; ?>"><?php echo $row1['cname']." - ".$row1['ccode']; ?></option>
                                        <?php
                                    }
                                }
                                }
                                    ?>
                                    </select>
                                </div>
                               
                            </div>
                                
                            <div class="form-group">
                                <label class=" form-control-label" style="color:#666; font-weight:500">Bill No</label>
                                    <div class="input-group" data-toggle="tooltip" data-placement="top" title="Bill Number">
                                        <div class="input-group-addon"><i class="fa fa-book"></i></div>
                                        <input class="form-control" type="text" name="billno" id="billno"
                                        placeholder="Bill Number" maxlength="40" required>
                                    </div>
                                       
                                </div>          
                               
                                <div class="form-group">
                                <label class=" form-control-label" style="color:#666; font-weight:500">Product</label>
                                    <div class="input-group">
                                       
                                        <select data-placeholder="Product" class="standardSelect" 
                                         tabindex="1"  name="pname" id="pname" onchange="pricecalc()" style="width:100%" required>
                                        <option value="option1" disabled selected>Product</option>

                                            <?php
                                        $fetch_products = mysqli_query($con, "select * from product_details where del=''");
                                        if(!$fetch_products){
                                            echo '
                                            <script>
                                                alert("database connectivity error);
                                            </script>
                                            ';
                                            echo mysqli_error($con);
                                        }else{
                                            if(mysqli_num_rows($fetch_products)<=0){
                                            
                                                ?>
                                        <option value="option2">No products found. Click here to add products<option>
                                                <?php
                                                }else{
                                        while($row2=mysqli_fetch_array($fetch_products)){
                                                $pcodeforstock = $row2['pcode'];
                                                $fetch_tstock = mysqli_query($con, "select tstock from stock_details where pcode='$pcodeforstock' && del=''");
                                                if(!$fetch_tstock){
                                                echo '
                                                <script>
                                                    alert("database connectivity error);
                                                </script>
                                                ';
                                                echo mysqli_error($con);
                                                }else{
                                                    $tstockf = "t";
                                                    while($srow=mysqli_fetch_array($fetch_tstock)){
                                                        $tstockf = $srow["tstock"];
                                                }
                                                }
                                            ?>
                                            <option value="<?php echo $row2['pcode']."*".$row2['sunit']."*".$row2['pricepersunit']."*".$row2['nospsunit']."*".$tstockf; ?>"><?php echo $row2['pname']; ?></option>
                                            <?php
                                        }
                                    }
                                    }
                                        ?>
                                            
                                        </select>
                                    </div>
                                   
                                </div>
                                <div class="form-group">
                                <label class=" form-control-label" style="color:#666; font-weight:500">Price per selling unit</label>
                                    <div class="input-group" data-toggle="tooltip" data-placement="top" title="Price per selling unit">
                                        <div class="input-group-addon"><i class="fa fa-inr"></i></div>
                                        <input class="form-control" type="number" maxlength="10" 
                                        placeholder="Price per Selling unit" name="pricepersunit" id="pricepersunit" oninput="pricecalc2()" required
                                        readOnly><div class="input-group-addon" id="rd" onclick="rd()"><i class="fa fa-pencil"></i></div>
                                    </div>
                                </div>
                              
                                <div class="form-group">
                                <label class=" form-control-label" style="color:#666; font-weight:500">Quantity</label>
                                    <div class="input-group" data-toggle="tooltip" data-placement="top" title="Quantity">
                                        <div class="input-group-addon"><i class="fa fa-tags"></i></div>
                                        <input class="form-control" type="number" maxlength="10" 
                                        placeholder="Quantity" name="quantity" id="quantity" oninput="pricecalc2()" required>
                                    </div>
                                </div>
                                
                                <div style="text-align:right; font-size:14px;font-weight:500; color:green; display: none" id="cstockdiv">
                                            Current Stock : <span id="cstockplus"></span><span id="cstockadd"></span>
                                            <span id="calc" style="color:#666"></span>
                                    </div>

                                <div class="form-group">
                                <label class=" form-control-label" style="color:#666; font-weight:500">Total Price</label>
                                    <div class="input-group" data-toggle="tooltip" data-placement="top" title="Total Price">
                                        <div class="input-group-addon"><i class="fa fa-inr"></i></div>
                                        <input class="form-control" type="number" placeholder="Total Price" name="price" maxlength="12"
                                         id="price" required>
                                    </div>
                                </div>
                                <div class="form-group" >
                                <label class=" form-control-label" style="color:#666; font-weight:500">Remarks</label>
                                    <div class="input-group" data-toggle="tooltip" data-placement="top" title="Remarks">
                                        <textarea 
                                        rows="1" placeholder="Remarks" class="form-control" id="remarks" name="remarks" maxlength="100"></textarea>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="input-group">
                                        <button type="submit" name="submit" class="btn btn-success btn-block" 
                                       >Upload</button>
                                    </div>
                                </div>
                                <center><b><a 
                                    href="slview.php">View Sales Report</a></b></center>

                               <input type="text" id="slcode" name="slcode" style="height: 1px;visibility: hidden;display:inline" >
                               <input type="text" id="lstock" name="lstock" style="height: 1px;visibility: hidden;display:inline" >
                               <input type="text" id="rstock" name="rstock" style="height: 1px;visibility: hidden;display:inline" >
                               <input type="text" id="tstock" name="tstock" style="height: 1px;visibility: hidden;display:inline" >
                            </div>
                        </form>
                        </div>
                    </div>
<?php
    if(isset($_POST["submit"])){
        if(($_POST["date"] != "") && ($_POST["billno"] != "") && ($_POST["cname"] != "") && 
        ($_POST["pname"] != "") && ($_POST["quantity"] != "") && ($_POST["price"] != "") && ($_POST["pricepersunit"] != "") && ($_POST["slcode"] != "") 
        && ($_POST["lstock"] != "")&& ($_POST["rstock"] != "")&& ($_POST["tstock"] != "")){

            $slcode = $_POST["slcode"];
            $check_duplicate_code = mysqli_query($con,"select * from sales_details where slcode='$slcode'");
                    if(mysqli_num_rows($check_duplicate_code)>0){
                        echo '<script>
                        alert("Network Connectivity Error. Please try again");  
                        window.location.href="slentry.php";                                                          
                        </script>'; 
                        
                    }
                    else{
                        $date = $_POST["date"];
                        $billno = $_POST["billno"];
                        $ccodearr = explode("*",$_POST["cname"]);
                        $pcode = $_POST["pname"];
                        $pcode2 = explode("*",$pcode);
                        $quantity = $_POST["quantity"];
                        $price = $_POST["price"];
                        $pricepersunit = $_POST["pricepersunit"];
                        $remarks = $_POST["remarks"];
                        $lstock = $_POST["lstock"];
                        $rstock = "-".$_POST["rstock"];
                        $tstock = $_POST["tstock"];

                        $add_sl_query = mysqli_query($con, "insert into sales_details values('$slcode',
                                '$ccodearr[0]','$date','$billno','$pcode2[0]','$quantity','$pricepersunit','$price','$remarks','')");
                                $update_stock = mysqli_query($con, "update stock_details set 
                                cstock='$lstock',
                                rstock='$rstock',
                                tstock='$tstock' where pcode='$pcode2[0]' ");
                           //use ccodearr to add sales price to cd table amountbl Num(ccodearr[1] + price)
                                if(!$add_sl_query){
                                    echo '<script>
                                    alert("Upload failed - database upload error");                                                            
                                    </script>'; 
                                    echo mysqli_error($con);
                                }
                                else{
                                    if(!$update_stock){
                                        echo '<script>
                                    alert("Upload failed in stocks table - But has been success in production table");                                                            
                                    </script>'; 
                                    echo mysqli_error($con);
    
                                    }else{
                                    echo '<script>
                                    alert("Upload Success");    
                                    window.location.href = "slview.php";                                                        
                                    </script>';
                                }
                            }

                    }
        }
        else{
            echo '
            <script>
            alert("Please fill in all the fields before proceeding further");
            window.location.href="slentry.php";
            </script>
            ';
        }
    }
?>
                  

                    <script>
                        function rd() {
                            
                            let d = document.getElementById("pricepersunit").readOnly;
                            document.getElementById("pricepersunit").readOnly = !d;
                        }

                        function pricecalc(){
                            let q = document.getElementById("quantity").value;
                            let pnamevalue = document.getElementById("pname").value;
                            document.getElementById("cstockdiv").style.display = "block";
                            if(pnamevalue == "option2"){
                                window.location.href="addp.php";
                            }
                            
                            let up = pnamevalue.split("*");
                            document.getElementById("cstockplus").innerHTML = up[4];
                            document.getElementById("lstock").value = up[4];

                            if(pnamevalue!=""){
                                document.getElementById("pricepersunit").value = up[2];
                                // document.getElementById("price").value = Number(q)*Number( document.getElementById("pricepersunit").value);
                                pricecalc2();
                            }
                        }
                        function pricecalc2(){
                            let q = document.getElementById("quantity").value;
                            let up = document.getElementById("pricepersunit").value;
                            let pnamevalue = document.getElementById("pname").value;
                            let nospsunit = pnamevalue.split("*");
                            document.getElementById("cstockadd").innerHTML=" - "+Number(q)*Number(nospsunit[3]);
                            document.getElementById("rstock").value=Number(q)*Number(nospsunit[3]);
                            document.getElementById("tstock").value=Number(document.getElementById("lstock").value)-Number(document.getElementById("rstock").value);
                            if(up!=""){
                                document.getElementById("price").value = Number(q)*Number(up);
                            }
                        }
                        function validate() {
                            let date = document.getElementById("date").value.length;
                            let billno = document.getElementById("billno").value.length;
                            let cname = document.getElementById("cname").value.length;
                            let pname = document.getElementById("pname").value.length;
                            let quantity = document.getElementById("quantity").value.length;
                            let price = document.getElementById("price").value.length;
                            let pricepersunit = document.getElementById("pricepersunit").value.length;
                            let remarks = document.getElementById("remarks").value.length;
                            let slcode = document.getElementById("slcode").value.length;
                            let lstock = document.getElementById("lstock").value.length;
                            let rstock = document.getElementById("rstock").value.length;
                            let tstock = document.getElementById("tstock").value.length;

                            if(document.getElementById("cname").value =="option1"){
                                alert("Please select the Customer name");
                                return false;
                            }
                            if(document.getElementById("cname").value =="option2"){
                                alert("No customers found. Click Ok to add customers");
                                window.location.href="addc.php";
                                return false;
                            }
                            
                            if(document.getElementById("pname").value =="option1"){
                                alert("Please select the Product name");
                                return false;
                            }
                            if(document.getElementById("pname").value =="option2"){
                                alert("No products found. Click Ok to add products");
                                window.location.href="addp.php";
                                return false;
                            }

                            if(date>10 || date==0){
                                alert("Invalid date. Please select a valid date");
                                return false;
                            }
                            if(billno>40){
                                alert("Please limit the Bill number to 40 characters");
                                return false;
                            }
                            if(billno==0){
                                alert("Please fill the Bill number before proceding further");
                                return false;
                            }
                            if(cname>12){
                                alert("Error while fetching Customer name");
                                return false;
                            }
                            if(cname==0){
                                alert("Please select the Customer Name before proceding further");
                                return false;
                            }
                            if(pname==0){
                                alert("Please select the product before proceding further");
                                return false;
                            }
                            if(price==0){
                                alert("Price field is empty. Fill it in to proceed further");
                                return false;
                            }
                            if(price>12){
                                alert("Please limit the price field to be within 12 digits");
                                return false;
                            }
                            if(pricepersunit==0){
                                alert("Price per selling unit field is empty. Fill it in to proceed further");
                                return false;
                            }
                            if(pricepersunit>10){
                                alert("Please limit the Price per selling unit field to be within 10 digits");
                                return false;
                            }
                            if(quantity==0){
                                alert("Please fill the quantity before proceding further");
                                return false;
                            }
                            if(quantity>10){
                                alert("Please limit the quantity field to be within 10 digits");
                                return false;
                            }
                            if(remarks>100){
                                alert("Please limit the remarks field to 100 characters");
                                return false;
                            }
                            if(slcode==0){
                                slcodegen();
                                let slcode2 = document.getElementById("slcode").value.length;
                                if(slcode2==0){
                                    alert("SLCode not generated. Please try again");
                                    return false
                                }
                            }
                            if(slcode>10){
                                    alert("SLCode generation error. Please try again");
                                    return false
                                }
                            if(lstock==0){
                                alert("Error while filling Last Stock. Please try again");
                                return false;
                            }
                            if(rstock==0){
                                alert("Error while filling Recent Stock. Please try again");
                                return false;
                            }
                            if(tstock==0){
                                alert("Error while filling Total Stock. Please try again");
                                return false;
                            }
                            return true;
                        }

                        function slcodegen() {

                            let op = document.getElementById("cname").value;
                            if(op == "option2"){
                                window.location.href="addc.php";
                            }
                            let randomnum1  =(Math.floor(Math.random() * 999) + 1);
                            let randomnum2  =(Math.floor(Math.random() * 9) + 1);
                            let randomchar1 = String.fromCharCode(65 + (Math.floor(Math.random() * 26)));
                            let randomchar2 = String.fromCharCode(65 + (Math.floor(Math.random() * 26)));
                            let randomchar3 = String.fromCharCode(65 + (Math.floor(Math.random() * 26)));

                            document.getElementById("slcode").value = randomchar1 + randomnum1 + randomnum2 + randomchar2+ randomchar3;
                        
                        }
                    </script>

                </div>
            </div><!-- .animated -->
        </div><!-- .content -->

    </div><!-- /#right-panel -->

    <!-- Right Panel -->
    <script>
        function winp(){
            alert("Work in Progress. Please check it out later");
        }
    </script>

<script src="vendors/jquery/dist/jquery.min.js"></script>
<script src="vendors/popper.js/dist/umd/popper.min.js"></script>
<script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="assets/js/main.js"></script>
<script src="vendors/chosen/chosen.jquery.min.js"></script>

<script>
    jQuery(document).ready(function() {
        jQuery(".standardSelect").chosen({
            disable_search_threshold: 10,
            no_results_text: "Oops, nothing found!",
            width: "100%"
        });
    });
</script>

</body>

</html>
